---
title: Mars/Pluto
page_type: axis
slug: mars-pluto
status: source_ingested
framework_scope: comparative
factors:
  - Mars
  - Pluto
normalized_axis: Mars/Pluto
factor_a: Mars
factor_b: Pluto
related_activations:
  - Mars/Pluto = Admetos
  - Mars/Pluto = Apollon
  - Mars/Pluto = Asc
  - Mars/Pluto = Chiron
  - Mars/Pluto = Cupido
  - Mars/Pluto = Hades
  - Mars/Pluto = Jupiter
  - Mars/Pluto = Kronos
  - Mars/Pluto = MC
  - Mars/Pluto = Mercury
  - Mars/Pluto = Moon
  - Mars/Pluto = Neptune
  - Mars/Pluto = Node
  - Mars/Pluto = Poseidon
  - Mars/Pluto = Saturn
  - Mars/Pluto = Sun
  - Mars/Pluto = Uranus
  - Mars/Pluto = Venus
  - Mars/Pluto = Vernal Point
  - Mars/Pluto = Vulcanus
  - Mars/Pluto = Zeus
related_triad_hubs:
  - Mars Chiron Pluto
  - Mars Jupiter Pluto
  - Mars Neptune Pluto
  - Mars Pluto Admetos
  - Mars Pluto Apollon
  - Mars Pluto Asc
  - Mars Pluto Cupido
  - Mars Pluto Hades
  - Mars Pluto Kronos
  - Mars Pluto MC
  - Mars Pluto Node
  - Mars Pluto Poseidon
  - Mars Pluto Vulcanus
  - Mars Pluto Zeus
  - Mars Saturn Pluto
  - Mars Uranus Pluto
  - Mercury Mars Pluto
  - Moon Mars Pluto
  - Sun Mars Pluto
  - Venus Mars Pluto
  - Vernal Point Mars Pluto
aliases:
  - Pluto/Mars
source_pages:
  - alfred-witte-ludwig-rudolph-hermann-lefeldt-rules-for-planetary-pictures
  - udo-rudolph-abc-fur-planetenbilder
  - reinhold-ebertin-the-combination-of-stellar-influences
  - michelle-falis-planet-combinations-astrological-brainstorms
  - john-sandbach-midpoints-a-kabbalistic-compendium-of-meanings-for-astrological-midpoints
  - robert-hand-horoscope-symbols
  - michael-munkasey-midpoints-unleashing-the-power-of-the-planets
  - hajo-banzhaf-anna-haebler-keywords-for-astrology
updated_at: 2026-06-20
---

## Identity

- Axis: `Mars/Pluto`
- Astronomicon axis: `U/Z`
- Canonical page type: comparative axis page grounded in source-native pair entries.

## Source Entries

### Alfred Witte, Ludwig Rudolph & Hermann Lefeldt - Rules for Planetary Pictures

- Source heading: `MARS/PLUTO`
- Source page: `239`

#### Pair Summary

Organizing. Planning. Plans. Duplicate, to copy, to repeat, to multiply. To lead, to supervise or to perform several activities at the same time. To divide, to split, to branch off. To work alternately at different tasks. To do different kinds of work. To work on schedule. Transformation and change in the activity in one’s work and in the working conditions. Actively bring about change.

### Udo Rudolph - ABC for Planetary Pictures

#### ABC Pair Summary

Change of work, developmental work, developmental impulses, evolutional work, working, wanting to change, changing actions, growing activity, and will development

### Reinhold Ebertin - The Combination of Stellar Influences

#### Principle

Superhuman power (force, brutality).

#### Psychological Correspondence

+ The ability to demonstrate extraordinary force and vigor, great self-confidence, obsessive about work, great ambition. - Attaining one's objectives through ruthlessness, brutality, cruelty. C A person who wants to use force or compulsion at every occasion.

#### Biological Correspondence

Replacement of natural organs and functions by artificial substitutes, such as artificial limbs (leg, arm, denture, skull).

#### Sociological Correspondence

Piece-workers, being paid for overtime work, great people in the sphere of sport. People disabled in war.

#### Probable Manifestations

+ Attainment of success through excessive effort. - Tendency to proceed in a brutal manner, the misfortune of having to suffer violent assaults, injuries. 44 Research on the charts of atomic research workers and rocket specialists and on the launching of earth satellites, etc., has revealed there was very frequently a Mars-Pluto contact, usually with the Sun. In other charts this combination can mean exceptional ability. Mars/Pluto o7f

### Michelle Falis - Planet Combinations: Astrological Brainstorms

#### Falis Entry

Powerful force. Powerful energy. Powerful actions. Buried anger. Buried rage. Buried energy. Stifled will. Volcanic rage. Explosive temper. Burning desire. Com pulsive desire. Controlling force. Forces beyond your control. Killer instincts. Catharsis through rage. Catharsis through physical activity. Feeling renewed through physical activity. Feeling renewed through sex. The desire to destroy and decimate. Needing to kill away the old to make way for new actions and inspi rations. The desire to kill. Compelled to control. Physical power. Physical control. Atomic power. Fight for survival. Fight for power. Fight to the death. Needing to prove something. Crime fighters. Criminals. Criminal underground. Underground activities. Thugs. Recycling energy. Healing energy. Intense energy. Energy that can transform what it touches. Intense force. Brutality. Cruelty. Abuse. Violence. Anti social behavior. Making people feel like they're walking on eggshells around you. Willingness to do what is necessary no matter how it displeases other people. Mak ing things happen without necessarily knowing why or how. Deeply unconscious actions. Deeply unconscious motivations for doing the things you do. Tapping into a deep reservoir of what needs to be done, or what is possible to do. Compulsive drive. Indefatigable effort. Relentlessness. Intense sexual energy. Dark sexual en ergy. Stifled sexual impulses. Buried sexual energy. Snuffed out. Sexual taboos. Violent taboos. Obsessed with sex. Obsessed with violence. Obsessed with win ning. Asserting power. Destructive actions. Destructive impulses. Regenerative im pulses. Drive to heal. Feeling compelled to transform. Driven to scrape off 'dead' aspects of yourself and your life. Weighed down by dead parts of yourself and of your life. The drive to destroy and renew. Tearing down decayed or dead parts your life. Cutting off from what is dead or dying. Tremendous courage. Keeping impulses under control. Controlling anger. Control ling your sex drive. Sexual compulsion. Too controlled. Keeping a lid on anger. Not relaxed. Wound tight. Not easy going. Stressed. Burning up inside. Strength. In tense orgasm. Violent orgasm. Strong sex drive. Initiating transformation. Active healing. Healing energy. Obsessive actions. Obsessive energy. Self-willed transfor mation. The courage to start over from scratch. Brave enough to keep going. Un ceasing control. Unceasing courage. Ruthlessness. Initiating catharsis. Instant transformation. Actively un-burying secrets. Actively burying secrets. Secretive ac tions. The drive to investigate and uncover. Leaving no stone unturned. Obsession with what is hidden. Physical obsessions. Transforming the body. Body builders. Weight lifters. People who need to release physical energy so they don't explode. Bitterness from storing too much energy. Nastiness from holding onto too much energy. Frustration from pent up energy. Impulse to annihilate. Physical feats. Single-minded focus. Consuming passions. Acting paranoid. Acting suspicious. Detectives. Spies. Mobsters. Inability to be detached. Innate understanding of cru elty, anger and aggression. Buried desires. Acting on your passions. Depression when passion in life is lacking. Frustration when there is nothing to put your all into. Anger, lashing out and cruelty when desires and passions are stifled or thwarted. Superhuman effort. Pushing yourself to the point of complete and utter exhaustion on all levels. Body-breaking effort. Tearing muscles to make new mus cles. Dominance or subservience. Physical trauma. Sexual trauma. Sexual abuse. Indomitable will. Anger that fuels transformation.

### John Sandbach - Midpoints: A Kabbalistic Compendium of Meanings for Astrological Midpoints

#### Principle

Intense aggression that may even be overpowering, or obsessive. The ability to get an extreme amount of work accomplished. Doing things that affect the whole world, or at least a great number of people. The desire to work toward a breakthrough. Domination of others, or running over them in an uncaring fashion. Extreme violence or brutality.

#### Process

The intensification of one’s actions so that one may perceive both their constructive and destructive aspects. The realization of one’s power to effect deep and profound changes.

### Robert Hand - Horoscope Symbols

#### Pair Delineation

Striving, hard work. To contend against difficult odds, often successfully. Brutality and conflict. Ambition, ruthless drive, the desire to achieve one's objectives at all costs.

### Michael Munkasey - Midpoints: Unleashing the Power of the Planets

- Source heading: `MARS/PLUTO`
- Source page: `239`

#### Basic Ideas

Heated arguments, the courage to raise suspicions, and aggravation at polluting or contamination practices, are central to these themes. Here you find the energy to purify or change that which is undesirable or imperfect; stimulation to be deceptive, corrupt, or degenerate; and a loosening of your destructive tendencies. These motifs bring endurance and energy for fights or battles, stimulate you to overcome any obstacle, help you control aggression, and put you in situations where you are forced to retaliate or punish others. They increase your sexual passions, bring extremes of irritation or displeasure, and activate your courage to reverse or overthrow that which is corrupt or needs drastic change. They help provoke struggles or battles against evil forces and give you the energy or will to set out after furious disputes to correct that which you feel needs reversal or adjustment despite the opposition.

#### In Your Personal Life

- Thesis: Courage or energy to pursue the most difficult or goals or challenges; sticking thru to the end despite encountering the most dire or dreadful circumstances; impulses to correct wrongs; steady applications of effort.
- Anti: Base feelings which push you to prolong gratification from practices which deplete people or resources; raising the heat of battle, or retaliating; aggravation over corruption or waste of people or resources.

#### In Your Relationships

- Thesis: Mean emotional reactions from others; turning emotions around and working with your partner in business or social schemes; counters the suspicions of others with suggestions for better planning or approaches.
- Anti: Giving in to the lowest forms of pornographic or deviant behavior; provoking arguments for the sheer enjoyment of battle; stimulates passions thru using lewd or profane remarks, gestures, or activities.

#### With Body or Mind

An over-productive pituitary gland; active cell regeneration or production; rectal irritation; tumors; toxemia or diseases in the sexual organs; massive fevers.

#### In Politics or Business

- Thesis: Security forces allied with the military; conducting clandestine operations; using police or military against criminal elements; energy to clean up surroundings; attacks using powerful forces and weaponry.
- Anti: A police state with rigid military controls; the use of suppression and torture as a means for enforcing policy; exporting upheaval and political theory to others as an objective; wars, rape, mayhem, chaos.

#### Munkasey Concepts Companion

- [Michael Munkasey - Mars/Pluto Concepts](../derived/munkasey-mars-pluto-concepts.md)

### Hajo Banzhaf and Anna Haebler - Keywords for Astrology

- Source section: `Mars-Pluto: Tremendous Power`
- PDF page(s): `323`

#### Banzhaf/Haebler Aspect Keywords

- archetype: The Invincible Warrior and His Invisible Power
- shadow: The Possessed Torturer and the Black Magician
- comparison: Strength Power Greed Possession Crude Subtle Muscle strength Magical power Fist Curse Destruction Transformation Operating Healing magically
- general: The courage for deep-reaching transformation . Greed for power and power struggles . Sexual possession . Uncanny , irresistible , or dark forces .
- harmony: Mack the Knife. Development of immense, usually invisible strengths that originate in a deep energy of the soul. Strong, secretive, and irresistible aura. Being able to compel others without showing any recognizable outer signs of doing so. Spooky, invincible, decisive, courageous, and fascinating. Strong sexual energies and deep passion. Total intensity.
- discord: The Sadist. Inconsiderate, unconditional, fanatic assertion of one's own will. Rigorous, bestial desire for revenge when rejection has been suffered. Extremely instinctive and possessed by sexual obsessions. Seeks total lust. Sexuality as the venue for power struggles. Loves (violent) sexual humiliations. As a result of social ostracism of this topic, the aspect is frequently lived out on a completely unconscious level.

## Comparative Schema

- core meaning: source-native axis statements from each ingested source are preserved side by side above.
- psychology: aphoristic, experiential, aspect-family, and thesis/anti formulations remain source-native instead of being flattened together.
- body/health: sources that isolate bodily implications keep them inside their own entries, and Munkasey adds an explicit `With Body or Mind` field.
- social/relationship: interpersonal implications remain inside their source blocks, and Munkasey's relationship thesis/anti stays separate.
- events/manifestations: Munkasey adds politics/business axis emphases, Carter remains axis-level aspect doctrine where present, and oriented activation pages stay unchanged.
- conflicts/notes: source `+` headings are normalized as midpoint-axis identities, and Munkasey's page-3 `CONCEPTS` list lives on the linked companion page instead of being merged into doctrine.

## Related Activations

- [Mars/Pluto = Admetos](../activations/mars-pluto-equals-admetos.md)
- [Mars/Pluto = Apollon](../activations/mars-pluto-equals-apollon.md)
- [Mars/Pluto = Asc](../activations/mars-pluto-equals-asc.md)
- [Mars/Pluto = Chiron](../activations/mars-pluto-equals-chiron.md)
- [Mars/Pluto = Cupido](../activations/mars-pluto-equals-cupido.md)
- [Mars/Pluto = Hades](../activations/mars-pluto-equals-hades.md)
- [Mars/Pluto = Jupiter](../activations/mars-pluto-equals-jupiter.md)
- [Mars/Pluto = Kronos](../activations/mars-pluto-equals-kronos.md)
- [Mars/Pluto = MC](../activations/mars-pluto-equals-mc.md)
- [Mars/Pluto = Mercury](../activations/mars-pluto-equals-mercury.md)
- [Mars/Pluto = Moon](../activations/mars-pluto-equals-moon.md)
- [Mars/Pluto = Neptune](../activations/mars-pluto-equals-neptune.md)
- [Mars/Pluto = Node](../activations/mars-pluto-equals-node.md)
- [Mars/Pluto = Poseidon](../activations/mars-pluto-equals-poseidon.md)
- [Mars/Pluto = Saturn](../activations/mars-pluto-equals-saturn.md)
- [Mars/Pluto = Sun](../activations/mars-pluto-equals-sun.md)
- [Mars/Pluto = Uranus](../activations/mars-pluto-equals-uranus.md)
- [Mars/Pluto = Venus](../activations/mars-pluto-equals-venus.md)
- [Mars/Pluto = Vernal Point](../activations/mars-pluto-equals-vernal-point.md)
- [Mars/Pluto = Vulcanus](../activations/mars-pluto-equals-vulcanus.md)
- [Mars/Pluto = Zeus](../activations/mars-pluto-equals-zeus.md)

## Contradictions

- No direct contradiction is recorded yet among the ingested source entries on this axis.
- Differences are preserved as distinct source voices, emphases, and source structures rather than flattened into one wording.

<a id="derived-synthesis"></a>

## Derived Synthesis

- `Mars/Pluto` is the axis of concentrated force, relentless action, survival drive, and transformative struggle. It combines initiative, aggression, sexuality, and physical effort with pressure, compulsion, control, and the urge to destroy what is corrupt or blocking progress.
- Chart expression: extraordinary stamina, courage under duress, strategic force, deep cathartic effort, and the capacity to fight through extreme resistance or crisis. Liabilities: brutality, coercion, revenge, obsession, destructive rage, violent conflict, and the use of power in ways that overwhelm others or the body itself.

## Links

- [Mars](../factors/mars.md)
- [Pluto](../factors/pluto.md)
- [Alfred Witte, Ludwig Rudolph & Hermann Lefeldt - Rules for Planetary Pictures](../sources/alfred-witte-ludwig-rudolph-hermann-lefeldt-rules-for-planetary-pictures.md)
- [Udo Rudolph - ABC for Planetary Pictures](../sources/udo-rudolph-abc-fur-planetenbilder.md)
- [Reinhold Ebertin - The Combination of Stellar Influences](../sources/reinhold-ebertin-the-combination-of-stellar-influences.md)
- [Michelle Falis - Planet Combinations: Astrological Brainstorms](../sources/michelle-falis-planet-combinations-astrological-brainstorms.md)
- [John Sandbach - Midpoints: A Kabbalistic Compendium of Meanings for Astrological Midpoints](../sources/john-sandbach-midpoints-a-kabbalistic-compendium-of-meanings-for-astrological-midpoints.md)
- [Robert Hand - Horoscope Symbols](../sources/robert-hand-horoscope-symbols.md)
- [Michael Munkasey - Midpoints: Unleashing the Power of the Planets](../sources/michael-munkasey-midpoints-unleashing-the-power-of-the-planets.md)
- [Hajo Banzhaf and Anna Haebler - Keywords for Astrology](../sources/hajo-banzhaf-anna-haebler-keywords-for-astrology.md)
