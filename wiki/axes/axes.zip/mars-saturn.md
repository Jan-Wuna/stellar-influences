---
title: Mars/Saturn
page_type: axis
slug: mars-saturn
status: source_ingested
framework_scope: comparative
factors:
  - Mars
  - Saturn
normalized_axis: Mars/Saturn
factor_a: Mars
factor_b: Saturn
related_activations:
  - Mars/Saturn = Admetos
  - Mars/Saturn = Apollon
  - Mars/Saturn = Asc
  - Mars/Saturn = Chiron
  - Mars/Saturn = Cupido
  - Mars/Saturn = Hades
  - Mars/Saturn = Jupiter
  - Mars/Saturn = Kronos
  - Mars/Saturn = MC
  - Mars/Saturn = Mercury
  - Mars/Saturn = Moon
  - Mars/Saturn = Neptune
  - Mars/Saturn = Node
  - Mars/Saturn = Pluto
  - Mars/Saturn = Poseidon
  - Mars/Saturn = Sun
  - Mars/Saturn = Uranus
  - Mars/Saturn = Venus
  - Mars/Saturn = Vernal Point
  - Mars/Saturn = Vulcanus
  - Mars/Saturn = Zeus
related_triad_hubs:
  - Mars Jupiter Saturn
  - Mars Saturn Admetos
  - Mars Saturn Apollon
  - Mars Saturn Asc
  - Mars Saturn Chiron
  - Mars Saturn Cupido
  - Mars Saturn Hades
  - Mars Saturn Kronos
  - Mars Saturn MC
  - Mars Saturn Neptune
  - Mars Saturn Node
  - Mars Saturn Pluto
  - Mars Saturn Poseidon
  - Mars Saturn Uranus
  - Mars Saturn Vulcanus
  - Mars Saturn Zeus
  - Mercury Mars Saturn
  - Moon Mars Saturn
  - Sun Mars Saturn
  - Venus Mars Saturn
  - Vernal Point Mars Saturn
aliases:
  - Saturn/Mars
source_pages:
  - alfred-witte-ludwig-rudolph-hermann-lefeldt-rules-for-planetary-pictures
  - udo-rudolph-abc-fur-planetenbilder
  - reinhold-ebertin-the-combination-of-stellar-influences
  - michelle-falis-planet-combinations-astrological-brainstorms
  - charles-carter-the-astrological-aspects
  - john-sandbach-midpoints-a-kabbalistic-compendium-of-meanings-for-astrological-midpoints
  - robert-hand-horoscope-symbols
  - michael-munkasey-midpoints-unleashing-the-power-of-the-planets
  - hajo-banzhaf-anna-haebler-keywords-for-astrology
updated_at: 2026-06-20
---

## Identity

- Axis: `Mars/Saturn`
- Astronomicon axis: `U/W`
- Canonical page type: comparative axis page grounded in source-native pair entries.

## Source Entries

### Alfred Witte, Ludwig Rudolph & Hermann Lefeldt - Rules for Planetary Pictures

- Source heading: `MARS/SATURN`
- Source page: `227`

#### Pair Summary

Periodic work. Interruption of work. Sickness. Acute sicknesses. Current affairs. Interruption. The act of separation. Forced separation. A general interruption. Activities leading to separation or which are periodically interrupted. End of action. The main formula for death.

### Udo Rudolph - ABC for Planetary Pictures

#### ABC Pair Summary

Activities in old age, grim actions, patience work, storten will, hard work, concentrated actions, Jangsam work, problematic work, grim activity, separation actions, and lossful actions

### Reinhold Ebertin - The Combination of Stellar Influences

#### Principle

Harmful or destructive energy. Inhibited or destroyed vitality.

#### Psychological Correspondence

+ Endurance, power of resistance, indefatigable. - Concentrated energy outwardly expressed as violence or inwardly shown as destructive power, hardness, harshness or bitterness, self-willed, obstinate. One's interest in any enterprise or activity lasts only such time as is required for overcoming the main difficulties. C Tendency to be injured, mostly destructive or pernicious forms of energy.

#### Biological Correspondence

Bone-forming process, joints, muscles as active factors and bones as passive factors, joining spots of the tendons or sinews with the bones. An inflammation of the bones or of the bone marrow. The death or atrophy of an organ, particularly paralysis of the muscles belonging to the breathing mechanism. (Death through suffocation.)

#### Sociological Correspondence

Manual laborers, miners. Energetic people who are able to overcome the greatest difficulties.

#### Probable Manifestations

+ The more energy the more difficulties are overcome, or vice versa. - Periods of impotence and weakness alternating with periods of brutal or ruthless progress and advancement in life. All will-directed activity meets complete resistance (as governed by circumstances). Tests of strength, disputes, separations, illnesses. Cases of death. 37 One is inclined at times to consider Mars/Satum as the "death axis." This combination is found in many cases at the time of death, but one should not make the mistake of taking it for granted that death will result. During the course of life this "death axis" is very often stimulated by transits and directions, but life continues. Such periods are often marked by difficulties and illness, difficulties to be overcome or the death of other people. It should also be taken into consideration that life is often prolonged through medical science or new medical equipment through which many people near death are kept alive. Mars/Saturn cT/*?

### Michelle Falis - Planet Combinations: Astrological Brainstorms

#### Falis Entry

Holding back energy. Holding yourself in check. Holding back aggression. Not physically demonstrative. Restricted force. Limited. Tightly controlled physical ac tions. A narrow channel in which to act. Cock block. Obstacles to action. Obstacles in your path. Rage from feeling limited. Feeling that you have a limited effect on your world. Having grown up being told what not to do. Growing up constantly being told "No." Fear-based self-control. Feeling limited in what you are capable of accomplishing. Limited achievements. Limited victories. Victory through hard work. Accomplishment through hard work. True grit. Making real, hard won achievements. Steady effort. Disciplined effort. Defining masculinity. The definition of bravery. Staying the course. Feeling that your efforts go unacknowledged. Feel ing that there is a big "NO" to confront every time you want to do something. "That's not how you do it." Feeling that you are always dealing with problems. Understated force. Physical strain. Physical stress. Physical limitations. Restricted energy flow. Hardened. Rigid, mechanical actions. Feeling that you have limited choices. Anger with au thority figures. Getting aggressive with authority figures. Angry with your father. Violent with older people. Becoming more aggressive as you get older. Learning how to act like an authority. Learning what it means to act like an authority. Conser vative actions. Exercise routines. Police officers. Hating police officers. Going from fighting authority figures to becoming an authority figure. Working class heroes. Few opportunities to go for it. Timeless bravery. Fighting for the establishment. Fighting against the establishment. Fighting against your father. Classic gentlemen. Codes of conduct. Traditional masculine roles. Adult behavior. Acting older than your age. Maturing early. Resisting maturity. Resisting aging. Fighting against getting older. Fighting against parental figures. Feeling that there are rules of behavior. There are rules for how men should act. There are rules for what you should and should not be doing. Acting within certain parameters. Being able to follow rules. The ability to take direction without asking questions. Under standing what the unspoken rules are. Breaking the mold requires tremendous ef fort. Making the mold. Molding behavior. Setting the rules. Disciplinarians. At tempting to dominate through rules and regulations. Strictness. Hard edges. Sex ual discipline. Wanting to tie people up. Serious sex. Adult sex. Sexual desire to be in an authoritative position. Wanting to be dominated. Wanting to be disciplined. Rules for sex. Setting sexual guidelines. Serious effort. Reliable. Willing to take re sponsibility no matter how much of a burden. Willing to keep trudging forward. Die Hard. Fulfilling your duty. Keeping order. Learning to be assertive. Learning to how to get what you want. Attempting to get what you want by following the rules. Doing things in a step by step manner. Fol lowing protocol. Establishing guidelines. Pushing past obstacles. Meeting resis tance. Developing fortitude. Stripping down to the bare essentials. Getting down to basics. Too frightened to do anything. Feeling caged. Doing things the hard way. Getting what you want is hard. Hard labor. Hard work. Doing hard time. Not know ing what to do with yourself when someone isn't putting limitations on you. Want ing someone to keep you in line. Needing a coach or trainer. Becoming a coach or trainer. Learning physical discipline. Needing structure, rules and guidelines to achieve your best. Scorched earth. A cold way of acting. Recognizing the need to act- because time is running out. Acute awareness of the reality and consequences of actions. Serious competitors. Real men.

### Charles Carter - The Astrological Aspects

#### Harmonious Aspects

These planets can only be said to act harmoniously, in the full sense of the word, when they are in good aspect and also well placed in other respects. In other circumstances they tend to produce a greater or less degree of hardship of some kind, though other good features may appear.

This combination is excellent for those who have to undergo hardship or danger. The Martian influence is, as it were, tempered, and rendered more adaptable, ordered and controlled, while the Saturnian is energized and made more enterprising and courageous. Such people have as a rule small regard for personal comfort or even safety, and may be excellent explorers, rulers of savage tribes or organisers of men needing firm control. It denotes orderly and courageous action, endurance and sound practical abilities.

It tends to hardship, self-abnegation and a disciplined life.

Probably good for all occupations that bring the native into contact with rough or dirty conditions, and primitive types of men.

#### The Conjunction

A very powerful and in some cases dangerous combination. If other influences agree there may be a distinct danger of unusual psychic suffering. It occurs in the nativities of several victims of violence (such as Don Carlos of Portugal, and Mrs. Bennett, who was strangled). All Inharmonious combinations of these planets appear to point this way. In the map of the Empress of Austria the two planets are in mutual reception. In one case (Conj. In Virgo in 2nd) there was great suffering from eczematic gout with chronic irritation. In two more instances there were severe burns, illustrating the marked tendency of this combination to cause injury to the skin, said by some to be ruled by Saturn as the significator of the limits of the body. Blows, cuts and stabs sometimes occur, often as the result of falls.

Although this configuration must be regarded as of serious import it is necessary to judge it carefully, and to give full weight to possible counteracting influences.

#### Inharmonious Aspects

These are frequently stated in text-books to be of a violent character, indicating brutality, cruelty and bloodlust.

It may at once be said that this is by no means invariably the case; in fact, the writer has at least two friends with this combination (the Square) who are conspicuously kind and in fact gentle, there being of course other indications of this nature in their maps.

It may be said that it may incline to a certain hardness and sternness, but if the rest of the horoscope is good this may be necessary to the native by reason of his occupation and the tempers of those with whom he has to deal. Again, the severity may be turned inward and there may be an inner austerity and self-discipline.

Its chief effect on character appears to be of a quite different kind. The Saturnian influence acts as a brake on the Martian energies, and I have certainly often noticed a sort of erraticity in these people, so that their enthusiasms are sudden and violent, but short-lasting, with alterations of "blowing hot" and "blowing cold." Sometimes there are spells of laziness, due to the inhibition of the Mars action; sometimes there is a restless energy without good directing common sense when Mars overcomes Saturn. Definite purpose often seems lacking, as if the native regarded life as something of a child's game, passing from one interest to another lightly and inconsequentially. However much in earnest such people are (and often they seem very much so), I have noticed that they commonly forget their pursuits as soon as they cease to amuse them. True depth is generally deficient. In one case there was great love of starting fresh enterprises and considerable ability in this way; but the native soon lost interest in them when the initial difficulties had been surmounted, and left them to another; here Mars was also Square Uranus.

There is usually a certain amount of selfishness or egoism. Thus, even when there is real kindness of heart, the native likes to go his own way, and will not readily turn aside from what interests him personally in order to minister to others. There is an inclination to impatience with those who do not readily agree.

Exteriorly Mars-Saturn tends to a life of hardship and suffering, as well as to the undergoing of physical violence.

The former may occur in the way of health. There is a danger of strain and excess; and this may be followed by the need for prolonged rest, rigid attention to dietetic and other restrictions, and otherwise "paying the price.

It seems to have a distinct affinity with enteric fever.

There is also a liability to burns and scaldings(*).

The Square is not uncommon in the horoscopes of victims of murdering, as for instance King Humbart, Willie Starchfield and Savonarola. In all such cases other potent factors will occur in addition, for the bad aspect of two planets (as apart from Sun, Moon and Angles) cannot, however serious, destroy the life prematurely or violently.

General Charles Gordon had the two planets in Trine, but Mars was debilitated by sign. The same occurs in the case of Alexander II of Russia (killed by bomb).

It does not by any means forbid success, though this will come late and after severe struggles.

(*)Mars-Saturn seems connected with fire in a wide sense, for Warren Leland, who lost wife and children in a great fire and died of shock in consequence, had them in Conjunction. Also Dr. Alfred Russell Wallace, who lost his scientific collections by fire, had them in Square. In another case communicated to me privately an officer with this aspect was recommended for the D.S.O., but never received this decoration because the papers were destroyed by fire and the recommending officer was killed at the same time.

General Observations

These planets in combination nearly always add to the energy, although, as stated, there may be great fitfulness of activity, and, in Inharmonious cases, a lack of tact and common-sense in dealing with others.

#### Examples

- Harmonious: Disraeli, General Gordon, Emile Zola, Dr. Besant, C.W. Leadbeater, Mary Pickford, Ludendorff
- The Conjunction: Don Carlos of Portugal, H.P. Blavatsky, Thomas Moore, James I, Mussolini, the "Young Pretender."
- Inharmonious: Charles Dickens, Jay Gould, Pierpont Morgan, Frederick the Great, President Ebert, Swedenborg, Savonarola.

### John Sandbach - Midpoints: A Kabbalistic Compendium of Meanings for Astrological Midpoints

#### Principle

To be careful and organized when one acts. The desire to be right and suc cessful in one’s actions, which could potentially inhibit one’s ability to act. Repressing anger leads to much pent-up energy and frustration which can potentially drain one. Feeling inadequate about one’s sexual abilities. The desire for certainty and always knowing the outcome of things, which, at worst, can have a debilitating effect on one’s creativity and ability to be open to what the universe has to offer. On the positive side, this combination can manifest great technical skill and the ability to accomplish some thing based on careful and planned-out agendas.

#### Process

To assertively make boundaries, and to actively organize experience. To concentrate and focus one’s efforts and to maintain patience and persistence when working through blockages and difficulties.

### Robert Hand - Horoscope Symbols

#### Pair Delineation

Inhibited actions, inhibited anger, frustration.

Disciplined or concentrated energies, hard work, energy focused on narrow objectives, the ability to perform painstaking work. In charts of both sexes, often associated with difficult father relationships. In women's charts, often signifies difficulties with males in general.

### Michael Munkasey - Midpoints: Unleashing the Power of the Planets

- Source heading: `MARS/SATURN`
- Source page: `227`

#### Basic Ideas

This combination of stop and go urges you forward, but then applies the brakes. You exercise restraint and self-control in your use of your force or energy, have great endurance thru your personal strength, and encounter activity which persists. You place much emphasis on your physical abilities, and the throwing of caution to the wind as recklessness prevailing over caution is common. You encounter delays at the start of projects, dilemmas which are not psychologically easy to resolve, hard and rigid reactions from others, and a restlessness with self-discipline. You balance caution vs. action, violence vs. restraint, and come by controlled periods of noisy and energetic outbursts. You find activity which must be repeated monotonously (as in assembly lines), have trouble applying responsibility, and show anger when dealing with frustrations or limiting restrictions. You are a cautious competitor.

#### In Your Personal Life

- Thesis: The cultivation of discipline in sports or physical training programs; an impulse to heat up a cold activity; obligations imposed to provide liveliness; ambition which is put into motion; serious efforts.
- Anti: Activity which is frozen by restrictions or incompetence; struggles that are prolonged; anger which lasts; the introduction of ignorance; noise which persists; the arousal of dormant frustrations; diminishing urges.

#### In Your Relationships

- Thesis: Increased ability to work out problems relating to activity vs. restraint, and caution vs. recklessness in relationships; working out the anger your partner directs at you, or vice-versa, into more positive activities.
- Anti: Aroused irritation that you turn and direct at your partner; prompts you to see your faults and difficulties as being caused by your partner; you see your partner as a person who blocks your best efforts.

#### With Body or Mind

High blood pressure; health problems caused by the blockage of energy or emotion; hyper followed by hypo; frustration; muscles which weaken or wither.

#### In Politics or Business

- Thesis: Curtailing force or military power by authorities; enforcement of honor thru the use of strife or struggle; wars which persist; frustrations imposed upon or by criminal elements; demands to halt armaments.
- Anti: Military actions which continue under political or other restrictions; an obligation to use force when restraint is required; the ambitious taking of that which belongs to another; an older enterprise becomes angered.

#### Munkasey Concepts Companion

- [Michael Munkasey - Mars/Saturn Concepts](../derived/munkasey-mars-saturn-concepts.md)

### Hajo Banzhaf and Anna Haebler - Keywords for Astrology

- Source section: `Mars-Saturn: Controlled Energy`
- PDF page(s): `320`

#### Banzhaf/Haebler Aspect Keywords

- archetype: The Spartan Warrior and His Old Teacher
- shadow: The Wicked Mercenary and the Grim Man Without Mercy
- comparison: Drive Resistance Spontaneity Responsibility Youth Age Hot Cold Rash Experienced Quick Slow Short Long Instinctual Ascetic Unrestrained Controlled Setting out Departing Beginning End
- general: Consistent , unyielding , or grim work . Fighting to the (bitter) end . Fighting against resistance . Gritting one's teeth . Cold war . Controlled or suppressed urges . Stiffened powers . Driving with the brakes on .
- harmony: The Untiring Individual. Purposeful energy. Persistently and resolutely finishes what has been started. Enormous use of force that continues to increase when there is resistance. Reliably, decisively, resolutely, and conscientiously carries out assignments. Can pull oneself together and hold out whenever it's necessary to do so. In the area of sexuality, also untiring or, if required, ascetic.
- discord: The Frustrated Person. Great problems with aggression. Energy that is stimulated by constant resistance, making room for itself in a brutal and bone-breaking manner. Or lasting pent-up aggressions that turn inward as helpless anger. Fear of failure and inability. Sullenness, desire for revenge, cold-blooded rage, inner blocks and tensions.

## Comparative Schema

- core meaning: source-native axis statements from each ingested source are preserved side by side above.
- psychology: aphoristic, experiential, aspect-family, and thesis/anti formulations remain source-native instead of being flattened together.
- body/health: sources that isolate bodily implications keep them inside their own entries, and Munkasey adds an explicit `With Body or Mind` field.
- social/relationship: interpersonal implications remain inside their source blocks, and Munkasey's relationship thesis/anti stays separate.
- events/manifestations: Munkasey adds politics/business axis emphases, Carter remains axis-level aspect doctrine where present, and oriented activation pages stay unchanged.
- conflicts/notes: source `+` headings are normalized as midpoint-axis identities, and Munkasey's page-3 `CONCEPTS` list lives on the linked companion page instead of being merged into doctrine.

## Related Activations

- [Mars/Saturn = Admetos](../activations/mars-saturn-equals-admetos.md)
- [Mars/Saturn = Apollon](../activations/mars-saturn-equals-apollon.md)
- [Mars/Saturn = Asc](../activations/mars-saturn-equals-asc.md)
- [Mars/Saturn = Chiron](../activations/mars-saturn-equals-chiron.md)
- [Mars/Saturn = Cupido](../activations/mars-saturn-equals-cupido.md)
- [Mars/Saturn = Hades](../activations/mars-saturn-equals-hades.md)
- [Mars/Saturn = Jupiter](../activations/mars-saturn-equals-jupiter.md)
- [Mars/Saturn = Kronos](../activations/mars-saturn-equals-kronos.md)
- [Mars/Saturn = MC](../activations/mars-saturn-equals-mc.md)
- [Mars/Saturn = Mercury](../activations/mars-saturn-equals-mercury.md)
- [Mars/Saturn = Moon](../activations/mars-saturn-equals-moon.md)
- [Mars/Saturn = Neptune](../activations/mars-saturn-equals-neptune.md)
- [Mars/Saturn = Node](../activations/mars-saturn-equals-node.md)
- [Mars/Saturn = Pluto](../activations/mars-saturn-equals-pluto.md)
- [Mars/Saturn = Poseidon](../activations/mars-saturn-equals-poseidon.md)
- [Mars/Saturn = Sun](../activations/mars-saturn-equals-sun.md)
- [Mars/Saturn = Uranus](../activations/mars-saturn-equals-uranus.md)
- [Mars/Saturn = Venus](../activations/mars-saturn-equals-venus.md)
- [Mars/Saturn = Vernal Point](../activations/mars-saturn-equals-vernal-point.md)
- [Mars/Saturn = Vulcanus](../activations/mars-saturn-equals-vulcanus.md)
- [Mars/Saturn = Zeus](../activations/mars-saturn-equals-zeus.md)

## Contradictions

- No direct contradiction is recorded yet among the ingested source entries on this axis.
- Differences are preserved as distinct source voices, emphases, and source structures rather than flattened into one wording.

<a id="derived-synthesis"></a>

## Derived Synthesis

- `Mars/Saturn` is the axis of blocked force, disciplined effort, endurance, and action under pressure. It combines drive and assertion with restraint, delay, hardness, structure, and the reality of obstacles.
- Chart expression: stamina, technical precision, grit, survival power, and the ability to keep working through difficulty. But its tension is fundamental: frustration, stop-go energy, anger under compression, harshness, inhibition, fatigue, painful resistance, and periods in which will meets a hard external or bodily limit.

## Links

- [Mars](../factors/mars.md)
- [Saturn](../factors/saturn.md)
- [Alfred Witte, Ludwig Rudolph & Hermann Lefeldt - Rules for Planetary Pictures](../sources/alfred-witte-ludwig-rudolph-hermann-lefeldt-rules-for-planetary-pictures.md)
- [Udo Rudolph - ABC for Planetary Pictures](../sources/udo-rudolph-abc-fur-planetenbilder.md)
- [Reinhold Ebertin - The Combination of Stellar Influences](../sources/reinhold-ebertin-the-combination-of-stellar-influences.md)
- [Michelle Falis - Planet Combinations: Astrological Brainstorms](../sources/michelle-falis-planet-combinations-astrological-brainstorms.md)
- [Charles Carter - The Astrological Aspects](../sources/charles-carter-the-astrological-aspects.md)
- [John Sandbach - Midpoints: A Kabbalistic Compendium of Meanings for Astrological Midpoints](../sources/john-sandbach-midpoints-a-kabbalistic-compendium-of-meanings-for-astrological-midpoints.md)
- [Robert Hand - Horoscope Symbols](../sources/robert-hand-horoscope-symbols.md)
- [Michael Munkasey - Midpoints: Unleashing the Power of the Planets](../sources/michael-munkasey-midpoints-unleashing-the-power-of-the-planets.md)
- [Hajo Banzhaf and Anna Haebler - Keywords for Astrology](../sources/hajo-banzhaf-anna-haebler-keywords-for-astrology.md)
