---
title: Mercury/Pluto
page_type: axis
slug: mercury-pluto
status: source_ingested
framework_scope: comparative
factors:
  - Mercury
  - Pluto
normalized_axis: Mercury/Pluto
factor_a: Mercury
factor_b: Pluto
related_activations:
  - Mercury/Pluto = Admetos
  - Mercury/Pluto = Apollon
  - Mercury/Pluto = Asc
  - Mercury/Pluto = Chiron
  - Mercury/Pluto = Cupido
  - Mercury/Pluto = Hades
  - Mercury/Pluto = Jupiter
  - Mercury/Pluto = Kronos
  - Mercury/Pluto = Mars
  - Mercury/Pluto = MC
  - Mercury/Pluto = Moon
  - Mercury/Pluto = Neptune
  - Mercury/Pluto = Node
  - Mercury/Pluto = Poseidon
  - Mercury/Pluto = Saturn
  - Mercury/Pluto = Sun
  - Mercury/Pluto = Uranus
  - Mercury/Pluto = Venus
  - Mercury/Pluto = Vernal Point
  - Mercury/Pluto = Vulcanus
  - Mercury/Pluto = Zeus
related_triad_hubs:
  - Mercury Chiron Pluto
  - Mercury Jupiter Pluto
  - Mercury Mars Pluto
  - Mercury Neptune Pluto
  - Mercury Pluto Admetos
  - Mercury Pluto Apollon
  - Mercury Pluto Asc
  - Mercury Pluto Cupido
  - Mercury Pluto Hades
  - Mercury Pluto Kronos
  - Mercury Pluto MC
  - Mercury Pluto Node
  - Mercury Pluto Poseidon
  - Mercury Pluto Vulcanus
  - Mercury Pluto Zeus
  - Mercury Saturn Pluto
  - Mercury Uranus Pluto
  - Mercury Venus Pluto
  - Moon Mercury Pluto
  - Sun Mercury Pluto
  - Vernal Point Mercury Pluto
aliases:
  - Pluto/Mercury
source_pages:
  - alfred-witte-ludwig-rudolph-hermann-lefeldt-rules-for-planetary-pictures
  - udo-rudolph-abc-fur-planetenbilder
  - reinhold-ebertin-the-combination-of-stellar-influences
  - michelle-falis-planet-combinations-astrological-brainstorms
  - john-sandbach-midpoints-a-kabbalistic-compendium-of-meanings-for-astrological-midpoints
  - robert-hand-horoscope-symbols
  - michael-munkasey-midpoints-unleashing-the-power-of-the-planets
  - hajo-banzhaf-anna-haebler-keywords-for-astrology
updated_at: 2026-06-20
---

## Identity

- Axis: `Mercury/Pluto`
- Astronomicon axis: `T/Z`
- Canonical page type: comparative axis page grounded in source-native pair entries.

## Source Entries

### Alfred Witte, Ludwig Rudolph & Hermann Lefeldt - Rules for Planetary Pictures

- Source heading: `MERCURY/PLUTO`
- Source page: `171`

#### Pair Summary

The function of the nerves. External and internal motion. The development of the thinking. From thinking to understanding. To develop or transform a thought. Thinking and perception is one thing. The development or change of the opinion, of the outlook on life, or of the understanding.

### Udo Rudolph - ABC for Planetary Pictures

#### ABC Pair Summary

Development of the Youth, Developing thinking, conversations about evolution, media development, Opinion changes, Opinion development, Language development, Changing thinking, Growing traffic, and word exchange

### Reinhold Ebertin - The Combination of Stellar Influences

#### Principle

The art of persuasion, suggestion.

#### Psychological Correspondence

+ Restless thinking, good powers of observation, quick grasp of every situation, amazingly sharp criticism, intellectual triumph over others, slyness or cunning, crafty subtlety, diplomacy. - Hasty thinking and speaking, premature action or hastiness, the spirit of opposition. Irritability, impatience, over-estimation of self. C Wielding of influence through speaking or writing.

#### Biological Correspondence

Metabolism of the nervous system, fonnation of new nerve substance. Nervous irritation.

#### Sociological Correspondence

A convincing speaker, the power to influence the public or the masses, a critic, a writer. A plagiarist or demagogue. In short, persons who are guilty of fraudulent representation or misrepresentation in speaking or writing.

#### Probable Manifestations

+ Success as a speaker or writer (mostly in specialized fields), the attainment of public recognition. - Tendency to overtax one's strength, disturbances of the nervous system through excessive zeal or eagerness. Mercury/Pluto 5/f

### Michelle Falis - Planet Combinations: Astrological Brainstorms

#### Falis Entry

Mystery writers. Sleuths. Whodunnit? Crime writers. Tunnel vision. Fixation. Get ting stuck on a particular idea or concept. Obsessive thoughts. Secretive. Probing. Investigators. Researchers. Detectives. Paranoid. Deeply suspicious mind. Con spiracy theorists. Attempting to uncover plots where none may exist. Psychopath. Deranged. Powerful words and language - for better or worse. The power of per suasion. Withholding information to gain power. Using information to gain power over others. Keeping silent. Concealing your thoughts. The need for privacy in communication. Secret languages. Coded languages. Occult knowledge. The ferret. Healing words. Catharsis through language. Getting to the bottom of things. Speaking in absolutes. The dirty mind. Smutty. Sex on the brain. Thinking the worst of people. Trying to uncover everyone's deep dark secrets. Mentally turning some thing innocent into something else entirely. Deft. Subtle. Penetrating. Relentless. Passionate communication. Overwhelming people with words. Controlling people with words. Abusive language. Mind control. Thought control. Mind manipulation. Uncovering layers of thought. Plunging deeper and deeper into an idea or concept. Inability to gain distance from your own ideas. Lack of objectivity. Pushing your ideas on other people. Inability to consider another viewpoint. Impressing your opinions on others through sheer passion and conviction, not logic. Deeply healing conversations. The ability to cut to the core of an issue. Psychother apists. Cutting through the crap. A willingness to broach taboo subjects. A will ingness to bring unpopular topics out for discussion. A willingness to take a look at the problems that society would rather sweep under the rug. The need to purge dark thoughts through writing or conversation. Writing about the underworld. Looking to get to the root of problems. Looking to solve a mystery from the bottom up. Needing a mystery to unravel. Finding ways to rebirth the mind. Take an idea and transforming it - for better or worse. The ability to fully, fundamentally, and to tally, change your mind.

### John Sandbach - Midpoints: A Kabbalistic Compendium of Meanings for Astrological Midpoints

#### Principle

Mental obsessiveness. The tendency to be extremely opinionated. The need to transform the mind by clearing negative thinking. The ability to communicate in a powerful manner. Communication that is so intense it destroys itself, causing miscom munication or no communication. One tends to hold extreme ideas which could be transformative in a positive way, or destructive.

#### Process

The evolution of one’s mental powers through the breaking down of limiting ideas and ways of looking at things so that new ideas and perspectives may form that are increasingly closer to the true nature of reality. The waging of war between the de sire to communicate with oneself and the fear of doing so, and the externalizing of this into outer communication.

### Robert Hand - Horoscope Symbols

#### Pair Delineation

The desire to influence others, to mold others' thinking. Transformations and crises in thought. The ability to be a convincing speaker or teacher. Tendency to get involved in mental power struggles. Deep thinking with great insight into motivation and human psychology. The ability to investigate or do research.

### Michael Munkasey - Midpoints: Unleashing the Power of the Planets

- Source heading: `MERCURY/PLUTO`
- Source page: `171`

#### Basic Ideas

You may degrade or debase your thinking in ways that are subtle but important. Thru these themes you can gain an obsession with reasoning and thinking which can lead you into intense and drastic experiences where you will your ambitions to dominate another’s wishes. These themes indicate a push which gives you extreme thoughts about using death or destruction as an implement for control, a duality in your approach to sexual expression, and fanatical speculation and reasoning which takes you areas beyond normal social acceptance. They symbolize desires to imitate people who have achieved power and control, you may think little of using and abandoning others, or get an impetus to take revenge on those who have not followed your orders or instructions. You may have many secrets you are willing to discuss with others, and may consider injuring others to obtain needed information.

#### In Your Personal Life

- Thesis: Ambitions to perform more precise research; you can be ruthless in the ways you pursue sources of information; becoming obsessed with informing on others who tell secrets; learning how to interrogate.
- Anti: You have a paranoia about secrets and their disclosure; you can be very unforgiving with people who have not followed your rules; you are not above punishing others; acquiring very clever and cunning styles.

#### In Your Relationships

- Thesis: You attach yourself to another only after much thought, and when you give another your loyalty you expect the same in return; you have great depths of passion, and enjoy talk about the most intimate subjects.
- Anti: Stimulation from erotic literature and pictures; gaining enjoyment from bisexual sharing; increased needs to have control over your partner’s activities; consideration of using others for sex.

#### With Body or Mind

Pituitary or endocrine glandular imbalances are highlighted; breakdown of body tissue caused by toxins; degenerative nerve diseases; toxins in the lungs.

#### In Politics or Business

- Thesis: High security communications and intelligence activities; political talk which offers abrupt changes to some functions; communications satellites; news of space exploration, orbital weapons, or toxic gases.
- Anti: Secrets concerning the business community or transportation systems; communications within the intelligence gathering agencies; self-destructive impulses in business; breakdowns in the road networks.

#### Munkasey Concepts Companion

- [Michael Munkasey - Mercury/Pluto Concepts](../derived/munkasey-mercury-pluto-concepts.md)

### Hajo Banzhaf and Anna Haebler - Keywords for Astrology

- Source section: `Mercury-Pluto: Inquiring Mind`
- PDF page(s): `308`

#### Banzhaf/Haebler Aspect Keywords

- archetype: Faust and Mephistopheles
- shadow: The Rogue and the Reactionary
- comparison: Distance Intensity Objective Committed Superficial Cryptic Cunning Power Lightness Depth Intellect Magic
- general: Analytic and profound thought . Power of persuasion and the fixed idea . The magic of words or thoughts .
- harmony: Uncompromising Thought. Good powers of observation. Analytical, critical, probing mind. The gift and desire to convince the surrounding world of one's own opinions and perceptions. An urge to closely scrutinize, explore, and—without consideration of possible consequences—relentlessly reveal everything.
- discord: The Fixed Idea. Compulsive need to talk and communicate. Dogged and obsessive thinking. Not being able to let go of a thought once it has come into existence. Persuading others in a dogmatic manner. Brutal openness without consideration of ethics or morals. Misuse of power. Intolerant, underhanded, and selfish.

## Comparative Schema

- core meaning: source-native axis statements from each ingested source are preserved side by side above.
- psychology: aphoristic, experiential, aspect-family, and thesis/anti formulations remain source-native instead of being flattened together.
- body/health: sources that isolate bodily implications keep them inside their own entries, and Munkasey adds an explicit `With Body or Mind` field.
- social/relationship: interpersonal implications remain inside their source blocks, and Munkasey's relationship thesis/anti stays separate.
- events/manifestations: Munkasey adds politics/business axis emphases, Carter remains axis-level aspect doctrine where present, and oriented activation pages stay unchanged.
- conflicts/notes: source `+` headings are normalized as midpoint-axis identities, and Munkasey's page-3 `CONCEPTS` list lives on the linked companion page instead of being merged into doctrine.

## Related Activations

- [Mercury/Pluto = Admetos](../activations/mercury-pluto-equals-admetos.md)
- [Mercury/Pluto = Apollon](../activations/mercury-pluto-equals-apollon.md)
- [Mercury/Pluto = Asc](../activations/mercury-pluto-equals-asc.md)
- [Mercury/Pluto = Chiron](../activations/mercury-pluto-equals-chiron.md)
- [Mercury/Pluto = Cupido](../activations/mercury-pluto-equals-cupido.md)
- [Mercury/Pluto = Hades](../activations/mercury-pluto-equals-hades.md)
- [Mercury/Pluto = Jupiter](../activations/mercury-pluto-equals-jupiter.md)
- [Mercury/Pluto = Kronos](../activations/mercury-pluto-equals-kronos.md)
- [Mercury/Pluto = Mars](../activations/mercury-pluto-equals-mars.md)
- [Mercury/Pluto = MC](../activations/mercury-pluto-equals-mc.md)
- [Mercury/Pluto = Moon](../activations/mercury-pluto-equals-moon.md)
- [Mercury/Pluto = Neptune](../activations/mercury-pluto-equals-neptune.md)
- [Mercury/Pluto = Node](../activations/mercury-pluto-equals-node.md)
- [Mercury/Pluto = Poseidon](../activations/mercury-pluto-equals-poseidon.md)
- [Mercury/Pluto = Saturn](../activations/mercury-pluto-equals-saturn.md)
- [Mercury/Pluto = Sun](../activations/mercury-pluto-equals-sun.md)
- [Mercury/Pluto = Uranus](../activations/mercury-pluto-equals-uranus.md)
- [Mercury/Pluto = Venus](../activations/mercury-pluto-equals-venus.md)
- [Mercury/Pluto = Vernal Point](../activations/mercury-pluto-equals-vernal-point.md)
- [Mercury/Pluto = Vulcanus](../activations/mercury-pluto-equals-vulcanus.md)
- [Mercury/Pluto = Zeus](../activations/mercury-pluto-equals-zeus.md)

## Contradictions

- No direct contradiction is recorded yet among the ingested source entries on this axis.
- Differences are preserved as distinct source voices, emphases, and source structures rather than flattened into one wording.

<a id="derived-synthesis"></a>

## Derived Synthesis

- `Mercury/Pluto` is the axis of penetrating thought, persuasive intensity, research, and transformative communication. It combines language, analysis, and nervous alertness with secrecy, depth, pressure, compulsion, and the power to uncover what is hidden.
- Chart expression: investigation, psychological insight, strategic speech, powerful writing, relentless questioning, and the ability to influence others through concentrated thought or language. Liabilities: obsession, suspicion, manipulation, verbal coercion, mental power struggles, and communication so intense or secretive that it distorts trust and objectivity.

## Links

- [Mercury](../factors/mercury.md)
- [Pluto](../factors/pluto.md)
- [Alfred Witte, Ludwig Rudolph & Hermann Lefeldt - Rules for Planetary Pictures](../sources/alfred-witte-ludwig-rudolph-hermann-lefeldt-rules-for-planetary-pictures.md)
- [Udo Rudolph - ABC for Planetary Pictures](../sources/udo-rudolph-abc-fur-planetenbilder.md)
- [Reinhold Ebertin - The Combination of Stellar Influences](../sources/reinhold-ebertin-the-combination-of-stellar-influences.md)
- [Michelle Falis - Planet Combinations: Astrological Brainstorms](../sources/michelle-falis-planet-combinations-astrological-brainstorms.md)
- [John Sandbach - Midpoints: A Kabbalistic Compendium of Meanings for Astrological Midpoints](../sources/john-sandbach-midpoints-a-kabbalistic-compendium-of-meanings-for-astrological-midpoints.md)
- [Robert Hand - Horoscope Symbols](../sources/robert-hand-horoscope-symbols.md)
- [Michael Munkasey - Midpoints: Unleashing the Power of the Planets](../sources/michael-munkasey-midpoints-unleashing-the-power-of-the-planets.md)
- [Hajo Banzhaf and Anna Haebler - Keywords for Astrology](../sources/hajo-banzhaf-anna-haebler-keywords-for-astrology.md)
