---
title: Mercury/Uranus
page_type: axis
slug: mercury-uranus
status: source_ingested
framework_scope: comparative
factors:
  - Mercury
  - Uranus
normalized_axis: Mercury/Uranus
factor_a: Mercury
factor_b: Uranus
related_activations:
  - Mercury/Uranus = Admetos
  - Mercury/Uranus = Apollon
  - Mercury/Uranus = Asc
  - Mercury/Uranus = Chiron
  - Mercury/Uranus = Cupido
  - Mercury/Uranus = Hades
  - Mercury/Uranus = Jupiter
  - Mercury/Uranus = Kronos
  - Mercury/Uranus = Mars
  - Mercury/Uranus = MC
  - Mercury/Uranus = Moon
  - Mercury/Uranus = Neptune
  - Mercury/Uranus = Node
  - Mercury/Uranus = Pluto
  - Mercury/Uranus = Poseidon
  - Mercury/Uranus = Saturn
  - Mercury/Uranus = Sun
  - Mercury/Uranus = Venus
  - Mercury/Uranus = Vernal Point
  - Mercury/Uranus = Vulcanus
  - Mercury/Uranus = Zeus
related_triad_hubs:
  - Mercury Chiron Uranus
  - Mercury Jupiter Uranus
  - Mercury Mars Uranus
  - Mercury Saturn Uranus
  - Mercury Uranus Admetos
  - Mercury Uranus Apollon
  - Mercury Uranus Asc
  - Mercury Uranus Cupido
  - Mercury Uranus Hades
  - Mercury Uranus Kronos
  - Mercury Uranus MC
  - Mercury Uranus Neptune
  - Mercury Uranus Node
  - Mercury Uranus Pluto
  - Mercury Uranus Poseidon
  - Mercury Uranus Vulcanus
  - Mercury Uranus Zeus
  - Mercury Venus Uranus
  - Moon Mercury Uranus
  - Sun Mercury Uranus
  - Vernal Point Mercury Uranus
aliases:
  - Uranus/Mercury
source_pages:
  - alfred-witte-ludwig-rudolph-hermann-lefeldt-rules-for-planetary-pictures
  - udo-rudolph-abc-fur-planetenbilder
  - reinhold-ebertin-the-combination-of-stellar-influences
  - michelle-falis-planet-combinations-astrological-brainstorms
  - charles-carter-the-astrological-aspects
  - john-sandbach-midpoints-a-kabbalistic-compendium-of-meanings-for-astrological-midpoints
  - robert-hand-horoscope-symbols
  - michael-munkasey-midpoints-unleashing-the-power-of-the-planets
  - hajo-banzhaf-anna-haebler-keywords-for-astrology
updated_at: 2026-06-20
---

## Identity

- Axis: `Mercury/Uranus`
- Astronomicon axis: `T/X`
- Canonical page type: comparative axis page grounded in source-native pair entries.

## Source Entries

### Alfred Witte, Ludwig Rudolph & Hermann Lefeldt - Rules for Planetary Pictures

- Source heading: `MERCURY/URANUS`
- Source page: `163`

#### Pair Summary

Nerves. Practical thinking. Logic. Good mathematician. Revolutionary thoughts. Original. Rhythm. Telegrams. New information. Sudden inspiration. Surprising mails. Sudden news or information. Excited way of speaking. Technological mindset. The main axis for astrologers, astronomers, technicians or mathematicians.

### Udo Rudolph - ABC for Planetary Pictures

#### ABC Pair Summary

Exciting news, event report, agitated speaking, youth reform, medicn tcchnik, new thinking, reform language, rhythmic movements, restless youth, technical opinions, and traffic event

### Reinhold Ebertin - The Combination of Stellar Influences

#### Principle

Astuteness, intuition.

#### Psychological Correspondence

+ A revolutionary spirit and mind, shrewdness, inventive thinking, talent for speaking. Intuition, interest in or ability in technical science or engineering, physics, mathematics, rhythm, etc. The desire to be independent, intellectual flexibility, - "Too many irons in the fire," the inclination to scatter one's energies in too many directions at once, nervous haste, temporary or occasional confusion, tactless, brutal frankness, over-estimation of self, a contradicting disposition. C Self-will, moodiness, a good intellect.

#### Biological Correspondence

The spinal cord as defined by Burdach and Goll, disturbances of equilibrium (facial pains and migraine).

#### Sociological Correspondence

Mathematician, technician, physicist, a person engaged professionally in the study and application of rhythmics, cosmobiologist.

#### Probable Manifestations

+ The power to influence people, innovations, inventions, sudden cognition or perception. - Failures caused through scattering one's energies or doing everything in haste, nervousness, eccentric actions, upset and excitement. Mercury/Uranus 5/W

### Michelle Falis - Planet Combinations: Astrological Brainstorms

#### Falis Entry

Brilliance. Genius. Flashes of intuition. Instant comprehension. Leaps in under standing. Skipping steps in the learning process. Skipping a grade. Lightning-quick mind. Accelerated learning. Unconventional thought process. Bright ideas. Light bulb flashing over your head. Eureka! Crazy. Zany. Eccentric. Strange or absurd ideas. Bizarre conclusions. Kooky. Loony. Insane. Mad Hatter. Revolutionary think ing. Revolutionary ideas. Thinking outside the box. Harebrained schemes. The mad scientist. Brainstorms. Inventors. Experimental. Unusual interpretations. Unprece dented interpretations. Unconventional viewpoint. Making unexpected connec tions. Groundbreaking concepts. Independent mind. Precocious notions. Unpre dictable speech patterns. Erratic travel patterns. Irrational logic. Unusual sibling relationships. Eccentric siblings. Strange siblings. Aloof siblings. Brilliant siblings. Concern with modern thought, modern thinkers and modern ideas. Avant-garde concepts. Alien mind. Alien education. Extraterrestrial intelligence. Telling the truth. Original thinkers. A mind for technology. Progressive viewpoint. Breaking free from conventional thinking. Being able to present old information in a new way. Shock ing communication. Shocking language. Saying things simply for shock value. Say ing things simply to push people away. Using language to gain freedom from re striction. Scattered. Unable to stay with one topic or subject for any length of time. Sporadic interests. ADD. ADHD. Short attention span. The mind of an astrologer. Astrological thinking. Innovative thinking. People on the fringe. Unusual connections. An unpredictable way of communicating information. Connecting information in a unique way. Strange correlations. Short bursts of com munication. Erratic education. Gaps in your education. Unstable mind. Rebellious thoughts. Thoughts that liberate. Liberation through writing. Liberation through reading. Talking about freedom and independence. Declaring your independence from established ways of thinking, speaking or writing. Rebelling against estab lished ways of thinking, speaking or writing. An unconventional education. Erratic learning patterns. Alternative education. Education reform. On the cutting edge of trends in learning and education. Extreme ways of communicating. Using extreme language. Verbal outbursts. Making off color comments. Abnormal mind. Deviant thoughts. Mental disorders.

### Charles Carter - The Astrological Aspects

#### Harmonious Aspects

The contacts of these planets indicate some degree of original talent; they usually give a quick and capable mind, with a considerable degree of independence.

The native is very often clever in certain special directions, and he works well so long as he is fond of his work. Other matters, outside the range of his interests, often do not enter his vision at all; he is indifferent to them, and may seem very stupid in relation to them. Hence the contacts are not useful for the common affairs of life. The native may be brilliant rather than sound, intuitive rather than logical.

It is a common aspect in the maps of astrologers. We find it also in the natus of Senator Marconi (published in Astrology, March 1930). It seems to occur less frequently in the maps of natural scientists, and appears to have an affinity with the finer forces of nature. There is a weak Sextile in the case of Edison.

It is sometimes oratorical; the native is able to express himself well and has a dramatic sense. It inclines also to make the native popular. He may coin striking phrases, or, if a writer, he may invent characters that seize the popular imagination. It is often classical, while Neptune is more democratic and modernist.

It is an influence of mental dexterity, adroitness and appositeness.

The memory is often exceptionally good.

#### The Conjunction

This is also common in astrological maps - witness Morinus, Chaney, Sibley and Lilly.

It is a powerful, self-willed combination, varying from the wayward and stubborn type to the enlightened and talented. Generally speaking, the influence is not exceedingly marked, because the two planets are not dissimilar; but the will-power of Uranus is added to the intellect of Mercury, and there is a more colourful, dramatic, forceful mentality. It is independent, sensitive, proud and sometimes secretive; but these effects are much modified by the sign occupied. The native almost always lives his own life and resents interference very fiercely.

In undeveloped characters the influence is not good, and there is often little to show for it except pride and touchiness. Sometimes there is considerable eccentricity and conceit, and talent that cannot be properly utilized because of the native's self-will and lack of adaptability.

#### Inharmonious Aspects

These must be considered as serious obstacles to success, chiefly by reason of the unpopularity that they engender, this being often due to the native's brusqueness and lack of tact. The native is often exceedingly outspoken and lacking in direction, and makes enemies unnecessarily. He is often stubborn and self-willed.

It also indicates strange beliefs, usually of the self-exalting kind; the native may easily be persuaded that he or she is a chosen prophet, messenger or representative of those on high; the self-esteem is generally considerable, and the native readily accepts anything that panders to this vanity.

The abilities are often great - greater, perhaps, than with the Trine and Sextile - but they are often used injudiciously, either in foolish causes or in a manner that occasions trouble. Measureless conceit and self-will appear to be the basis of most of the errors, the native persisting in his illusions in the face of all opposition and reason - indeed these often seem to increase the stubbornness.

In some cases the effects are mainly external, and in such examples we find the native the target for more or less unmerited attacks of a bitter character, as for instance the slanders directed against the Prince Consort in the time of the Crimean War (*).

It is perhaps most fair to say, in this and similar cases, that the native's opinions will be at variance with those of his associates and others; but it is not always easy to judge astrologically which view is correct. In some instances the beliefs of the Mercury-afflictedby-Uranus native are almost universally rejected, as, for example the alleged supernatural revelations of Josesph Smith, the Mormon prophet, and the claims to special divine protection made by the ex-Kaiser. In other cases posterity may justify the native as against his assailants. As a general rule, I think, this type of affliction denotes definite wrong-headedness at least on some matters.

It is sometimes a criminal influence, apparently sufficing to turn the whole tenor of an otherwise not particularly evil map into the wrong direction.

(*) The horoscope of this gifted and conscientious man is likely to be a puzzle to those who use cut-and-dried interpretations, for he had his ruler, Mercury, in major affliction with all four malefics. I am inclined to think that a "Grand Cross" is much less evil than is supposed, at all events for the character. Just as the Grand Trine is admittedly less benefic than might be expected.

#### Examples

- Harmonious: Abbas Effendi, Marchese Marconi, Duchess of York, Joseph Chamberlain, G.B. Shaw, Lord Oxford (H.H. Asquith).
- The Conjunction: Pasteur, Camille Flammariron, Lord Rosebery, William Lilly.
- Inharmonious: President Ebert, W. Gornold ("Sepharial"), Mrs. Besant, A.J. Balfour, Frederick the Great, Victor Hugo, Henry Irving, Oscar Wilde, James Coates (mesmerist), Gassendi, Francis Bret Harte, Marie Bashkertseff, William I and William II of Germany, Hindenburg, John Burns.

### John Sandbach - Midpoints: A Kabbalistic Compendium of Meanings for Astrological Midpoints

#### Principle

Independent thinking. Strange ideas. A progressive mind. Thinking outside the box and experimenting with ideas. Sudden communication that can catch people off guard. The ability to say things in a unique or unusual way. A spasmodic scattering of energies that can create upset and/or cause failure due to not putting enough energy into any one thing.

#### Process

The liberating of one’s thoughts from unnecessarily limiting biases. Allowing one’s mind to find its own individualized way of thinking and communicating. To ex plore new modes of sharing information and to free the mind so that it can perceive ideas in new ways and in new relationships to each other.

### Robert Hand - Horoscope Symbols

#### Pair Delineation

Lightning-like mind, tendency to be scattered and become nervous through haste. Sudden decisions or thoughts. Need for intellectual stimulation and excitement, need for the unusual. Often relates to ability in mathematics, science, or technology or to involvement in occult techniques such as astrology.

### Michael Munkasey - Midpoints: Unleashing the Power of the Planets

- Source heading: `MERCURY/URANUS`
- Source page: `163`

#### Basic Ideas

This combination symbolizes expressing opinions while you remain emotionally detached and aloof from the subject matter. These themes prompt you to express ideas in clever ways, bring knowledge of and insight into mechanical or electrical methods, and allow you to understand information flows and processes, such as those used in computer or systems work. They heighten your interest in astrology and its application, and you may find yourself doing research or classifying information to see how or why technology works. You may quickly observe ways of doing things, and intuit how different procedures can be shortened or improved. Impertinent ways of expressing opinions, and a quick and ready wit which others may find abrasive are also indicated. You do your best work alone, but you also need friends and companions for the input and personal stimulation they provide.

#### In Your Personal Life

- Thesis: You work well with numbers and data, and understand electrical and mechanical concepts; you enjoy classifying information, and are known as a ‘jack-of -alltrades’; you excel at revising another’s work.
- Anti: You have a brilliant but eccentric mind; your sarcasm and wit disturbs others; you do not care for people as much as you care for numbers and data; you are quick to argue over the smallest details; a dry personality.

#### In Your Relationships

- Thesis: You and your partner establish and keep psychological boundaries between each other; you accept another’s individuality and need for space in a relationship, but ask that yours also be respected.
- Anti: You have such a need to express your self-identity that you do not care about the feelings of others; you find it difficult to express your feelings about the relationship; you disturb others with your independent ways.

#### With Body or Mind

Intestinal and stomach gas; sensitivities to certain food groups (milk, wheat, etc.); nervousness and restlessness as a personal trait; easily stressed by others.

#### In Politics or Business

- Thesis: Breakthroughs in the communication or transmission of information; modernization of transportation networks or policies; business groups which form to help initiate policy; labor coalitions or unions at work.
- Anti: Rebellions or riots which start because information on goals is not well explained or defined; reform which causes disruptions in the transportation network; use of propaganda during emergencies.

#### Munkasey Concepts Companion

- [Michael Munkasey - Mercury/Uranus Concepts](../derived/munkasey-mercury-uranus-concepts.md)

### Hajo Banzhaf and Anna Haebler - Keywords for Astrology

- Source section: `Mercury-Uranus: Freedom of Thought`
- PDF page(s): `306`

#### Banzhaf/Haebler Aspect Keywords

- archetype: The Intellectual and the Enlightener
- shadow: The Know-It-All and the Madman
- comparison: Logic Intuition Exploring Inventing Student Revolutionary Thought Sudden inspiration
- general: Lucid , wide-awake , willful thinking . Unconventional perceptions and erratic thinking . Unique ideas . Sudden insights .
- harmony: The Bright. Fast Thinker. Extremely quick intellectual grasp. Has the right idea at the right moment. May think a number of thoughts at the same time. Witty, original, inventive, flexible. Independent, sometimes eccentric standpoints. Unbiased, independent, progressive thinking. Full of ideas, but without any particular love of details.
- discord: The Scatterbrain. Eccentric leaps from one idea to another with sudden, abrupt, and hardly understandable turns. Extreme impatience, hastiness, and exaggeration in thinking. Poor listener (particularly for people who speak slowly), impatient student. Ingenious ideas and intrepid assertions, but without or inadequately thinking them through. Sometimes confused states with the feeling of being an intellectual live wire.

## Comparative Schema

- core meaning: source-native axis statements from each ingested source are preserved side by side above.
- psychology: aphoristic, experiential, aspect-family, and thesis/anti formulations remain source-native instead of being flattened together.
- body/health: sources that isolate bodily implications keep them inside their own entries, and Munkasey adds an explicit `With Body or Mind` field.
- social/relationship: interpersonal implications remain inside their source blocks, and Munkasey's relationship thesis/anti stays separate.
- events/manifestations: Munkasey adds politics/business axis emphases, Carter remains axis-level aspect doctrine where present, and oriented activation pages stay unchanged.
- conflicts/notes: source `+` headings are normalized as midpoint-axis identities, and Munkasey's page-3 `CONCEPTS` list lives on the linked companion page instead of being merged into doctrine.

## Related Activations

- [Mercury/Uranus = Admetos](../activations/mercury-uranus-equals-admetos.md)
- [Mercury/Uranus = Apollon](../activations/mercury-uranus-equals-apollon.md)
- [Mercury/Uranus = Asc](../activations/mercury-uranus-equals-asc.md)
- [Mercury/Uranus = Chiron](../activations/mercury-uranus-equals-chiron.md)
- [Mercury/Uranus = Cupido](../activations/mercury-uranus-equals-cupido.md)
- [Mercury/Uranus = Hades](../activations/mercury-uranus-equals-hades.md)
- [Mercury/Uranus = Jupiter](../activations/mercury-uranus-equals-jupiter.md)
- [Mercury/Uranus = Kronos](../activations/mercury-uranus-equals-kronos.md)
- [Mercury/Uranus = Mars](../activations/mercury-uranus-equals-mars.md)
- [Mercury/Uranus = MC](../activations/mercury-uranus-equals-mc.md)
- [Mercury/Uranus = Moon](../activations/mercury-uranus-equals-moon.md)
- [Mercury/Uranus = Neptune](../activations/mercury-uranus-equals-neptune.md)
- [Mercury/Uranus = Node](../activations/mercury-uranus-equals-node.md)
- [Mercury/Uranus = Pluto](../activations/mercury-uranus-equals-pluto.md)
- [Mercury/Uranus = Poseidon](../activations/mercury-uranus-equals-poseidon.md)
- [Mercury/Uranus = Saturn](../activations/mercury-uranus-equals-saturn.md)
- [Mercury/Uranus = Sun](../activations/mercury-uranus-equals-sun.md)
- [Mercury/Uranus = Venus](../activations/mercury-uranus-equals-venus.md)
- [Mercury/Uranus = Vernal Point](../activations/mercury-uranus-equals-vernal-point.md)
- [Mercury/Uranus = Vulcanus](../activations/mercury-uranus-equals-vulcanus.md)
- [Mercury/Uranus = Zeus](../activations/mercury-uranus-equals-zeus.md)

## Contradictions

- No direct contradiction is recorded yet among the ingested source entries on this axis.
- Differences are preserved as distinct source voices, emphases, and source structures rather than flattened into one wording.

<a id="derived-synthesis"></a>

## Derived Synthesis

- `Mercury/Uranus` is the axis of inventive thinking, sudden insight, mental independence, originality, and unconventional communication. It combines intellect with intuition, innovation, technical acuity, and the impulse to break from standard mental pathways.
- Chart expression: brilliance, breakthroughs, mathematics or technical skill, reformist thought, sharp wit, and the ability to perceive patterns or solutions suddenly. Its shadow is instability: scattered attention, nervous haste, tactless speech, contrariness, eccentricity, and ideas delivered so abruptly that they alienate more conventional minds.

## Links

- [Mercury](../factors/mercury.md)
- [Uranus](../factors/uranus.md)
- [Alfred Witte, Ludwig Rudolph & Hermann Lefeldt - Rules for Planetary Pictures](../sources/alfred-witte-ludwig-rudolph-hermann-lefeldt-rules-for-planetary-pictures.md)
- [Udo Rudolph - ABC for Planetary Pictures](../sources/udo-rudolph-abc-fur-planetenbilder.md)
- [Reinhold Ebertin - The Combination of Stellar Influences](../sources/reinhold-ebertin-the-combination-of-stellar-influences.md)
- [Michelle Falis - Planet Combinations: Astrological Brainstorms](../sources/michelle-falis-planet-combinations-astrological-brainstorms.md)
- [Charles Carter - The Astrological Aspects](../sources/charles-carter-the-astrological-aspects.md)
- [John Sandbach - Midpoints: A Kabbalistic Compendium of Meanings for Astrological Midpoints](../sources/john-sandbach-midpoints-a-kabbalistic-compendium-of-meanings-for-astrological-midpoints.md)
- [Robert Hand - Horoscope Symbols](../sources/robert-hand-horoscope-symbols.md)
- [Michael Munkasey - Midpoints: Unleashing the Power of the Planets](../sources/michael-munkasey-midpoints-unleashing-the-power-of-the-planets.md)
- [Hajo Banzhaf and Anna Haebler - Keywords for Astrology](../sources/hajo-banzhaf-anna-haebler-keywords-for-astrology.md)
