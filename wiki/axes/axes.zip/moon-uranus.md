---
title: Moon/Uranus
page_type: axis
slug: moon-uranus
status: source_ingested
framework_scope: comparative
factors:
  - Moon
  - Uranus
normalized_axis: Moon/Uranus
factor_a: Moon
factor_b: Uranus
related_activations:
  - Moon/Uranus = Admetos
  - Moon/Uranus = Apollon
  - Moon/Uranus = Asc
  - Moon/Uranus = Chiron
  - Moon/Uranus = Cupido
  - Moon/Uranus = Hades
  - Moon/Uranus = Jupiter
  - Moon/Uranus = Kronos
  - Moon/Uranus = Mars
  - Moon/Uranus = MC
  - Moon/Uranus = Mercury
  - Moon/Uranus = Neptune
  - Moon/Uranus = Node
  - Moon/Uranus = Pluto
  - Moon/Uranus = Poseidon
  - Moon/Uranus = Saturn
  - Moon/Uranus = Sun
  - Moon/Uranus = Venus
  - Moon/Uranus = Vernal Point
  - Moon/Uranus = Vulcanus
  - Moon/Uranus = Zeus
related_triad_hubs:
  - Moon Chiron Uranus
  - Moon Jupiter Uranus
  - Moon Mars Uranus
  - Moon Mercury Uranus
  - Moon Saturn Uranus
  - Moon Uranus Admetos
  - Moon Uranus Apollon
  - Moon Uranus Asc
  - Moon Uranus Cupido
  - Moon Uranus Hades
  - Moon Uranus Kronos
  - Moon Uranus MC
  - Moon Uranus Neptune
  - Moon Uranus Node
  - Moon Uranus Pluto
  - Moon Uranus Poseidon
  - Moon Uranus Vulcanus
  - Moon Uranus Zeus
  - Moon Venus Uranus
  - Sun Moon Uranus
  - Vernal Point Moon Uranus
aliases:
  - Uranus/Moon
source_pages:
  - alfred-witte-ludwig-rudolph-hermann-lefeldt-rules-for-planetary-pictures
  - udo-rudolph-abc-fur-planetenbilder
  - reinhold-ebertin-the-combination-of-stellar-influences
  - michelle-falis-planet-combinations-astrological-brainstorms
  - charles-carter-the-astrological-aspects
  - john-sandbach-midpoints-a-kabbalistic-compendium-of-meanings-for-astrological-midpoints
  - robert-hand-horoscope-symbols
  - michael-munkasey-midpoints-unleashing-the-power-of-the-planets
  - hajo-banzhaf-anna-haebler-keywords-for-astrology
updated_at: 2026-06-20
---

## Identity

- Axis: `Moon/Uranus`
- Astronomicon axis: `R/X`
- Canonical page type: comparative axis page grounded in source-native pair entries.

## Source Entries

### Alfred Witte, Ludwig Rudolph & Hermann Lefeldt - Rules for Planetary Pictures

- Source heading: `MOON/URANUS`
- Source page: `123`

#### Pair Summary

Awake. Rouse. Excite. Vibrating motion. Interest. Attention. Restlessness of the body and the mind. Womens ambition. Energetic woman. Hour of tension. Eventful hour. Uproar of the populace. Excitement. Nervousness of female persons. Uproars caused by women. Excited persons and people.

### Udo Rudolph - ABC for Planetary Pictures

#### ABC Pair Summary

Eventful hour, excited woman, excited gemtite, fiihls impulses, impulses of woman, ncue woman, nervous woman, reform woman, hour rhythm, iisurrapid woman, tjnruhe in the people, and people reform

### Reinhold Ebertin - The Combination of Stellar Influences

#### Principle

Emotional tensions. Sudden manifestation of subconscious forces.

#### Psychological Correspondence

+ Increased emotional excitability, attentiveness, ambition, tendency to act according to one's instincts, a strong self-will, tendency to strive tor a goal or objective, determination, an unconditional pursuit of one's own conviction, interest in the metaphysical sciences and realms (clairvoyance). - An excessive self-will, stubbornness, fanaticism, tendency to exaggerate or magnify things, inclination to strain the nerves, striving for absolute independence, unrest or restlessness, craving of sensation. C An over-strained emotional life, peculiar interests, intellectual talents, individualism.

#### Biological Correspondence

The rhythm of the water economy in the blood, blood pressure disturbances, colic of the water-excreting organs (prostate diseases). Connections with the female period.

#### Sociological Correspondence

Restless, nervous or ambitious women, female reformists.

#### Probable Manifestations

+ Sacrifices for the attainment of special aims, help and assistance through friends, attainment of sudden success, accomplishment of a change in one's circumstances. - Tendency to overdo things either in work or in the pursuit of objectives strains the nervous system. States of fear and anxiety. 23 Schizophrenic symptoms have been found at times, but one should be careful not to diagnose schizophrenia in the case of every Moon -Uranus aspect. If such a tendency is found there are usually additional factors which are inherited. Moon/Uranus D/W

### Michelle Falis - Planet Combinations: Astrological Brainstorms

#### Falis Entry

Unusual attachments. Unusual friends. Feeling comfortable with nonconformists. Feeling nurtured by astrology. Wanting to live in the future. Instinctively rebellious. Shocking responses. Unpredictable responses. Unpredictable emotions. An erratic emotional life. Unstable emotional life. Emotionally extreme. Extreme responses. Feeling chaotic. Feeling like a revolutionary. Feeling rebellious. Wanting to break free from family ties. Wanting to break free from family conditioning. Wanting to break free from ingrained habits. Wanting to be liberated from domestic life. Free dom from family. Freedom from country. Rebelling against the country. Sudden intuition. Emotional independence. Unusual home life. Liking strange and unusual things. Living in a futuristic house. Feeling at home with technology. Feeling like a geek. Feeling like an outcast. Bizarre eating habits. Bizarre habit patterns. Bizarre ways of showing you care. Inconsistent emotions. Needing space and freedom. Coldness. Needing room to breathe. Feeling that fam ily life is claustrophobic. Breaking free from mom. Having an independent mother. An unpredictable, erratic, or inconsistent mother. Getting along with independent, strong-willed, unusual women. Liking liberated, rebellious, unpredictable women. The Liberated Woman. Inability to completely conform. Feeling supported by tech nology. Feeling supported by astrology. Astrology groups. Feeling comfortable with chaos. Feeling comfortable with eccentricity. Feeling happy with weirdoes. Strange feelings. Unusual intuitions. Sudden emotional out bursts. Emotionally distant. Aloof. Kooky habits. Liking bizarre food. Shocking eat ing habits. Abnormal emotional responses. Abnormal eating habits. Abnormal habits. Abnormal mother. Deviant behavior. Cool emotions. Emotionally detached. Inconsistent feelings for people. Inconsistent eating habits. Strange cuisine. Emo tionally stubborn. Emotionally fixed. Cool relationships with family members. Feel ing emotionally supported by groups - or not. Changing feelings. Keeping everyone at arm's length. Avoiding deeper emotions. Avoiding deeper relationships. Avoid ing emotional bonding. Avoiding family. Disruptive behavior. Naturally original. Naturally unique. A natural eccentric. A natural nonconformist. Naturally peculiar. Peculiar behavior. Feeling happier going off the beaten path. Avoiding the predictable. Avoiding routine. Avoiding clingy relationships. Steering clear of motherly types. Choosing not to have a family. Choosing independence over family. Having a hard time reconciling warm, caring emotions with the need to be free of constraints. Difficulty demonstrating affection. Preferring to be free and alone rather than with someone and trapped. Crankiness. Occasionally feeling the need to break free from everyone and everything. Feelings of anarchy. Emo tional alienation. Alienated from your own feelings and emotional life. Comfortable living on the fringe.

### Charles Carter - The Astrological Aspects

#### Harmonious Aspects

These bodies have little in common, the Moon being concerned chiefly with the usual and the ordinary, whilst Uranus is of an exactly contrary nature.

The good aspects appear above all to bestow firmness and determination of a singularly unflinching kind, and, moreover, there is a distinct tendency for the native to interest himself in occultism, spiritist phenomena, Christian Science, and various cryptic matters, ranging from the less reputable up to the truly scientific and elevative, such as Astrology. Sometimes the effects of the contacts are apparently slight, and the same is often true, I believe, of directions between the same bodies. It seems that the good aspects favour the rigid performance of duty and make the native capable of enduring and sacrificing much for anything that he conceives as being an obligation or an ideal. He will be of the type that cannot be argued with; he seems to get his inspirations and beliefs from another world, or, as is sometimes said intuitively-a word often used to indicate feelings that cannot be justified rationally and are not to be submitted to rational analysis. Even the good aspects seem to make people too inflexible.

It is probable that they are also indications of help from friends, and in some cases they are certainly found in the maps of persons of extraordinary genius. Apart from such cases, the probability of helpful friends is, I think, almost the only practically useful result of these configurations, for the determination bestowed by them is a dubious boon unless the rest of the map offers promise that there is judgment and sense behind it.

#### The Conjunction

This is a powerful and often a dangerous position. There is high emotional tension. Sometimes the affections are strangely and (possibly) tragically bestowed; there is an element of perversity and great determination, which may be directed wisely or unwisely, but very rarely follows any conventional or usual course. The interests are nearly always strange, and both mind and feelings differ from

those of ordinary humanity, often giving rise to conditions with which it is exceedingly difficult for another to deal, because the native is deaf to reason and seems unable to help himself, there being a veritable paralysis of the judgment. Perhaps it is most perilous in Fire, and least so in Earth and Air, but I have known strange people with this aspect even in the latter element-they are, however, less excitable than those having it in Fire, their vagaries being more often intellectual. Things ordinary and common do not satisfy the nature at all, and the constant search for the marvelous may lead the native into all kinds of fantastic cults. Note particularly the strength of Mercury and Jupiter, for these planets may determine the measure and direction of the influence.

Since the Uranian seldom does things by half-measures this Conjunction may make a bad enemy (cp. Clemenceau), but as a general rule the afflictions of Uranus do not affect the moral nature (except unfortunately that they sometimes cause sexual abnormality), and I have never found those with this Conjunction to be unlikeable so much as they are (to non-astrologers) impossible to understand.

It tends very much to an individual sort of life, the native hating routine and being willing to submit to anything rather than loss of independence of thought and action.

#### Inharmonious Aspects

These aspects are by no means inimical to talent; they are in fact better in this respect than are the Trines and Sextiles. There is the same absorption in a special and usually peculiar pursuit that we find with the Conjunction, and there is likely to be a certain degree of self-will and perversity. But it must be admitted that there are many cases wherein the bad aspects of the Moon and Uranus figure in the maps of persons of outstanding intellectual qualities. In such cases the bad effects often appear to be largely externalized, perhaps in health and nervous tension, perhaps in sorrow or catastrophe through friendships and alliances. It appears that the possession of these aspects is a direct admonition to follow one's own path and to be extremely chary of accepting advice or of leaning on others(*).

They appear to generate great activity, mental and physical, but I have not always noted in the bad aspects the inflexibility that is found with the good ones. Astral and kindred phenomena are of frequent occurrence, and may "deceive the very elect," especially in these days when psychism often masquerades as spiritual science; but there is not the personal vanity which so often leads people to accept almost any delusions that minister to it.

Though there is generally one interest above all others in the life, it seems there is often great versatility.

(*) I have never inclined to the belief that Uranus is the true ruler of Aquarius; but it seems clear that the action of the planet is often via our friends and associates - this had been strongly borne upon me by the study of the cases used for this delineation. Those opposed to this rulership say that Uranus is too violent a planet for the mild and kindly Aquarius. But perhaps this aspect of Uranus has been exaggerated. Raphael says he is "wayward, stubborn, conceited…proud, malicious and jealous." My experience of persons with Uranus rising is more fortunate that this; they are commonly rough-and-ready, neither diplomatic nor tactful, but upon the whole I have found them good-natured and as loyal friends as most others. Their interests and opinions certainly are liable to alter drastically and there is usually more or less pronounced eccentricity, but the planet seems to have no adverse effect on the character, except perhaps to make them sensitive, as most highly-strung people are.

#### Examples

- Harmonious: Rupert Brooke, President Harding, "Sepharial", William Blake, Cecil Rhodes, James II, Thomas Hardy, Mary Pickford, Blackbourne, R.W. Emerson.
- The Conjunction: Lindberg, Swedenborg, Clemenceau, Duke of York, Gustav Stresemann (German Statesmen)
- Inharmonious: P.B. Marston, S.T. Coleridge, Oscar Wilde, Joseph Smith (Mormon), Czar Nicholas, Mrs. Annie Besant, Adeline Patti, Kaiser William II, W.J. Bryan, Rider Haggard.

### John Sandbach - Midpoints: A Kabbalistic Compendium of Meanings for Astrological Midpoints

#### Principle

Sudden changes of feeling, occurring because of the person needing to clear the emotional body. Odd, unusual, strange emotional states and/or unexpected reac tions to experiences. The ability to perceive things that others do not perceive. Upsets with one’s security. One finds security through freedom. The emotional need for inde pendence and to be able to pursue one’s own unique goals.

#### Process

The ability to perceive one’s own independent emotions as being separate from the feelings of others. Freely sharing one’s feelings. Liberation from attachments that are no longer needed.

### Robert Hand - Horoscope Symbols

#### Pair Delineation

Emotional need for freedom. Need for unusual emotional experiences. Sudden actions dictated by feeling, outbursts of emotion. Disruptions of old patterns of living, breaks with the past, disruptions in nurture.

### Michael Munkasey - Midpoints: Unleashing the Power of the Planets

- Source heading: `MOON/URANUS`
- Source page: `123`

#### Basic Ideas

The melding of these two patterns helps to nurture an inner rebelliousness against maternal or traditional family roles. It can denote emotional detachment and an erratic restlessness. These motifs will both agitate your emotions and your sensitive or nurturing side, yet they also bring insight and perception with an intuitive flair. These planets can represent an innovative wizard without emotional stability, but who has an inventive faculty which comes from working with uncommon ideas or materials. Here is the person whose innovative insights are so far removed from the center of mankind that the person may be truly labeled ‘an eccentric genius’. There is an impersonal sensitivity to tradition, as well as personal insights or uncertainties which breed nonconformity. Shown here is an unusual person whose insights into family needs can change the concept of life or living.

#### In Your Personal Life

- Thesis: You have a restlessness about family roles; inner pulls to balance nurturing and freedom needs; you gather impressions in an unusual way but can create objects appreciated by all; vulnerability vs. detachment.
- Anti: You are a brooding person who wrecks emotional havoc, especially on the lives of people close to you; you are a person whose emotional war within affects the lives of others too; you easily disrupt family life.

#### In Your Relationships

- Thesis: You are attracted to people who are emotionally sensitive but erratic; your relationships are based upon giving trust and caring to another person regardless of how well they can control their emotional life.
- Anti: You find it difficult to understand how your partner cannot control all parts of life; you only offer conditional nurturing or care based upon others curbing their emotions; you are intolerable of spontaneity.

#### With Body or Mind

Stomach spasms; extremes of eyesight (good or bad); changes in the body’s acid/ alkali balance; disruptions in female organs or ovaries; the stress of family life.

#### In Politics or Business

- Thesis: An enterprise with great insight into the needs of its people, yet one which has a very unusual way for showing care and appreciation toward its population; unconventional rulers with an emotional flair.
- Anti: Leaders who rule at their whim, with little or no sense of how their enterprise is seen by the rest of the world; an emotionally immature person placed in an important and visible leadership role.

#### Munkasey Concepts Companion

- [Michael Munkasey - Moon/Uranus Concepts](../derived/munkasey-moon-uranus-concepts.md)

### Hajo Banzhaf and Anna Haebler - Keywords for Astrology

- Source section: `Moon-Uranus: Emotional Dynamite`
- PDF page(s): `296`

#### Banzhaf/Haebler Aspect Keywords

- archetype: The Unique Queen and the Court Jester
- shadow: The Noncommittal Woman and the Agitator
- comparison: Closeness Distance Patience Impatience Dependence Independence Feeling of security Freedom Emotion Idea Monopolizing Taking flight
- general: Surprising , unpredictable , vacillating , crazy feelings . Longing for freedom and independence . Tension between closeness and distance . The spirit of departure . Electrifying feelings . Sudden emergence of unconscious powers . Emotional fireworks .
- harmony: The Genius at Improvising. Can spontaneously and easily adjust and adapt to new situations and people. Remains inwardly very flexible and always open for what is new. Yet, still capable of adequately integrating the need for a feeling of emotional security and the demand for independence and freedom.
- discord: The Individual Incapable of Commitment. Need for freedom that takes on a compulsive character. Can never really open up to anything on the emotional level. In any type of agreement, always keeps at least one (inner) loophole open.

## Comparative Schema

- core meaning: source-native axis statements from each ingested source are preserved side by side above.
- psychology: aphoristic, experiential, aspect-family, and thesis/anti formulations remain source-native instead of being flattened together.
- body/health: sources that isolate bodily implications keep them inside their own entries, and Munkasey adds an explicit `With Body or Mind` field.
- social/relationship: interpersonal implications remain inside their source blocks, and Munkasey's relationship thesis/anti stays separate.
- events/manifestations: Munkasey adds politics/business axis emphases, Carter remains axis-level aspect doctrine where present, and oriented activation pages stay unchanged.
- conflicts/notes: source `+` headings are normalized as midpoint-axis identities, and Munkasey's page-3 `CONCEPTS` list lives on the linked companion page instead of being merged into doctrine.

## Related Activations

- [Moon/Uranus = Admetos](../activations/moon-uranus-equals-admetos.md)
- [Moon/Uranus = Apollon](../activations/moon-uranus-equals-apollon.md)
- [Moon/Uranus = Asc](../activations/moon-uranus-equals-asc.md)
- [Moon/Uranus = Chiron](../activations/moon-uranus-equals-chiron.md)
- [Moon/Uranus = Cupido](../activations/moon-uranus-equals-cupido.md)
- [Moon/Uranus = Hades](../activations/moon-uranus-equals-hades.md)
- [Moon/Uranus = Jupiter](../activations/moon-uranus-equals-jupiter.md)
- [Moon/Uranus = Kronos](../activations/moon-uranus-equals-kronos.md)
- [Moon/Uranus = Mars](../activations/moon-uranus-equals-mars.md)
- [Moon/Uranus = MC](../activations/moon-uranus-equals-mc.md)
- [Moon/Uranus = Mercury](../activations/moon-uranus-equals-mercury.md)
- [Moon/Uranus = Neptune](../activations/moon-uranus-equals-neptune.md)
- [Moon/Uranus = Node](../activations/moon-uranus-equals-node.md)
- [Moon/Uranus = Pluto](../activations/moon-uranus-equals-pluto.md)
- [Moon/Uranus = Poseidon](../activations/moon-uranus-equals-poseidon.md)
- [Moon/Uranus = Saturn](../activations/moon-uranus-equals-saturn.md)
- [Moon/Uranus = Sun](../activations/moon-uranus-equals-sun.md)
- [Moon/Uranus = Venus](../activations/moon-uranus-equals-venus.md)
- [Moon/Uranus = Vernal Point](../activations/moon-uranus-equals-vernal-point.md)
- [Moon/Uranus = Vulcanus](../activations/moon-uranus-equals-vulcanus.md)
- [Moon/Uranus = Zeus](../activations/moon-uranus-equals-zeus.md)

## Contradictions

- No direct contradiction is recorded yet among the ingested source entries on this axis.
- Differences are preserved as distinct source voices, emphases, and source structures rather than flattened into one wording.

<a id="derived-synthesis"></a>

## Derived Synthesis

- `Moon/Uranus` is the axis of emotional freedom, restlessness, unconventional nurture, and sudden changes in habit or attachment. It combines feeling, memory, and domestic pattern with independence, surprise, tension, intuition, and the urge to break from emotional confinement.
- Chart expression: originality in private life, quick instinctive insight, nonconformity, reformist feeling, and the need for space inside relationships, family, and routine. Liabilities: instability, emotional detachment, erratic responses, nervous strain, disrupted security, and difficulty sustaining steady warmth when freedom and closeness feel incompatible.

## Links

- [Moon](../factors/moon.md)
- [Uranus](../factors/uranus.md)
- [Alfred Witte, Ludwig Rudolph & Hermann Lefeldt - Rules for Planetary Pictures](../sources/alfred-witte-ludwig-rudolph-hermann-lefeldt-rules-for-planetary-pictures.md)
- [Udo Rudolph - ABC for Planetary Pictures](../sources/udo-rudolph-abc-fur-planetenbilder.md)
- [Reinhold Ebertin - The Combination of Stellar Influences](../sources/reinhold-ebertin-the-combination-of-stellar-influences.md)
- [Michelle Falis - Planet Combinations: Astrological Brainstorms](../sources/michelle-falis-planet-combinations-astrological-brainstorms.md)
- [Charles Carter - The Astrological Aspects](../sources/charles-carter-the-astrological-aspects.md)
- [John Sandbach - Midpoints: A Kabbalistic Compendium of Meanings for Astrological Midpoints](../sources/john-sandbach-midpoints-a-kabbalistic-compendium-of-meanings-for-astrological-midpoints.md)
- [Robert Hand - Horoscope Symbols](../sources/robert-hand-horoscope-symbols.md)
- [Michael Munkasey - Midpoints: Unleashing the Power of the Planets](../sources/michael-munkasey-midpoints-unleashing-the-power-of-the-planets.md)
- [Hajo Banzhaf and Anna Haebler - Keywords for Astrology](../sources/hajo-banzhaf-anna-haebler-keywords-for-astrology.md)
