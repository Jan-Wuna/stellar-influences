---
title: Sun/Pluto
page_type: axis
slug: sun-pluto
status: source_ingested
framework_scope: comparative
factors:
  - Sun
  - Pluto
normalized_axis: Sun/Pluto
factor_a: Sun
factor_b: Pluto
related_activations:
  - Sun/Pluto = Admetos
  - Sun/Pluto = Apollon
  - Sun/Pluto = Asc
  - Sun/Pluto = Chiron
  - Sun/Pluto = Cupido
  - Sun/Pluto = Hades
  - Sun/Pluto = Jupiter
  - Sun/Pluto = Kronos
  - Sun/Pluto = Mars
  - Sun/Pluto = MC
  - Sun/Pluto = Mercury
  - Sun/Pluto = Moon
  - Sun/Pluto = Neptune
  - Sun/Pluto = Node
  - Sun/Pluto = Poseidon
  - Sun/Pluto = Saturn
  - Sun/Pluto = Uranus
  - Sun/Pluto = Venus
  - Sun/Pluto = Vernal Point
  - Sun/Pluto = Vulcanus
  - Sun/Pluto = Zeus
related_triad_hubs:
  - Sun Chiron Pluto
  - Sun Jupiter Pluto
  - Sun Mars Pluto
  - Sun Mercury Pluto
  - Sun Moon Pluto
  - Sun Neptune Pluto
  - Sun Pluto Admetos
  - Sun Pluto Apollon
  - Sun Pluto Asc
  - Sun Pluto Cupido
  - Sun Pluto Hades
  - Sun Pluto Kronos
  - Sun Pluto MC
  - Sun Pluto Node
  - Sun Pluto Poseidon
  - Sun Pluto Vulcanus
  - Sun Pluto Zeus
  - Sun Saturn Pluto
  - Sun Uranus Pluto
  - Sun Venus Pluto
  - Vernal Point Sun Pluto
aliases:
  - Pluto/Sun
source_pages:
  - alfred-witte-ludwig-rudolph-hermann-lefeldt-rules-for-planetary-pictures
  - udo-rudolph-abc-fur-planetenbilder
  - reinhold-ebertin-the-combination-of-stellar-influences
  - michelle-falis-planet-combinations-astrological-brainstorms
  - john-sandbach-midpoints-a-kabbalistic-compendium-of-meanings-for-astrological-midpoints
  - robert-hand-horoscope-symbols
  - michael-munkasey-midpoints-unleashing-the-power-of-the-planets
  - hajo-banzhaf-anna-haebler-keywords-for-astrology
updated_at: 2026-06-20
---

## Identity

- Axis: `Sun/Pluto`
- Astronomicon axis: `S/Z`
- Canonical page type: comparative axis page grounded in source-native pair entries.

## Source Entries

### Alfred Witte, Ludwig Rudolph & Hermann Lefeldt - Rules for Planetary Pictures

- Source heading: `SUN/PLUTO`
- Source page: `87`

#### Pair Summary

Physical transformation, development and change. To grow. The circulation of the fluids in the body. The physical assimilation of nourishment. The regeneration capacity of the body. The ability of the body to transform itself. Changes in living conditions. The function of the internal organs. (In the solar cycle: period of changes, turnarounds or developments.)

### Udo Rudolph - ABC for Planetary Pictures

#### ABC Pair Summary

Developmental center, evolution of the person, change of the year, bodily growth, physical transformation, human changes, personal change, personal unfolding, a changeable man, and a changeful day

### Reinhold Ebertin - The Combination of Stellar Influences

#### Principle

Striving for power, craving for rulership, power of attainment.

#### Psychological Correspondence

+ Striving for power by means of physical strength or mental energy, creative power, consciousness of aim or objective, an appreciation of innovations, qualities of leadership. - Craving for rulership, fanatical aspirations or tendencies, over-estimation of self, arrogance. C Desire to exercise power, craving for rulership and disadvantages through the former.

#### Biological Correspondence

Regeneration of the cells. Swellings.

#### Sociological Correspondence

Pioneers, fighters, persons accustomed to rule others (martyrs of their own ideas).

#### Probable Manifestations

+ Sudden advancement in life, ability to establish and consolidate one's own position as a leader, realization of new ideas. - Physical suffering, martyrdom. Danger to life, separation by providence. O/f

### Michelle Falis - Planet Combinations: Astrological Brainstorms

#### Falis Entry

Will power. Wanting to have power over others. Wanting to be powerful. Wanting to have the power that others have. Being involved with the government - for better or worse. Wanting a powerful position in the world. Needing to show or prove how powerful you are. Needing to show or prove your intensity of purpose. Powerful creative forces. A compulsive personality. An obsessive personality. Pitting yourself against people who are more powerful than you are. Allying with powerful people. Diving into your own depths. Getting to know your deepest self. Self-regeneration. Self-transformation. Psychoanalysts. Intense self-discovery. Throwing yourself into extreme situations to see what you're made of. Transformation through self perpetuated crisis. Grappling with a desire to explore the seedy side of life. Need ing to live a life beyond surface expectations. Needing to live a life of depth. Feeling compelled to interact with people who will tear down your ego. Feeling compelled to have someone rip you a new one from time to time. Bringing difficult circum stances upon yourself to test your own mettle. Shining a light into the totality of that which you are - the dark and the light. Blending and healing the dark with the light and the light with the dark. People who live close to death or deal with the dead or dying. People who live close to power. Living in the shadows. People who live on the dark side. Darth Vader. The Villain. A person who represents everything we hate in ourselves - everything we want to crush, disown, cast out or kill. You draw villainous people to you. You draw powerful personalities to you. You measure yourself against other powerful people. You measure yourself against the worst of society and claim, "I'm nothing like that!" or fear that you are exactly like that underneath it all. Identifying with the villain. Identifying with criminals. Identifying with powerful people. Identifying with the scourge of society. Identifying with healers and shamans. Identifying with your obsessions and compulsions. Identifying with processes of deep cleansing, trans formation and rebirth. Feeling empowered by life. Using power and intimidation to your advantage. Knowing how to intimidate peo ple. Having a powerful presence. Not suffering fools. Deep cleaning your ego. Hav ing extreme experiences for the sake of the learning experience. Power mongers. Despots. Polarizing individuals. These are people most people either love or hate. You know how to get under people's skin. Interrogators. Controlling personalities. Self-destruction. Self-annihilation. Purging. Living in the underworld. Criminals. Shining a light into the underworld. Entering where other people dare not step. Try ing to always keep the upper hand in all situations. Hiding your true self. Con cealing who you really are. Staying hidden. Self-imprisonment. Good self-control. Staying underground and off the radar. Self-obsessed. Paranoid. Obsessed with your own fame or other people's fame. Obsessed with your own self-expression. Children who are given too much power. Children who control the parents. Pow erful pride. Indomitable will. Power games and power struggles. Struggles for dominance. Being abused, or abusing others. Feeling powerless. Feeling over powered by life. Attempting to control the men in your life. Feeling controlled by the men in your life. Experiencing your father as a controlling person. The urge to dominate. Feeling that you are being dominated by others. Feeling that you have no control over your life. Feeling that your life is controlled by others. Feeling that your purpose is out of your hands. Finding deep healing resources within yourself Finding the capacity to fully and fundamentally transform who you are. People who take part in trans forming their generation's purpose. Regenerating the dead aspects yourself. Recog nizing your shadow self rather than casting it on other people.

### John Sandbach - Midpoints: A Kabbalistic Compendium of Meanings for Astrological Midpoints

#### Principle

A relentless craving for discovering the deepest meanings in life. Striving for personal power, be it mental, physical, or spiritual. Obsessiveness where goals are concerned. The transformation of the ego into a higher spiritual state, so that it may reflect the Divine Light. At worst, an intense desire for objectivity results in emotional repression.

#### Process

The intensification of ego pressures to the point that their limiting and block ing qualities are eradicated so that the Spiritual Light may shine forth. Discovery of the true meaning of life beyond all limited, materialistic and outward considerations.

### Robert Hand - Horoscope Symbols

#### Pair Delineation

The will to transform, to be effective, and to bring about regeneration. The will to destroy. The desire for power. Also the experience of pow-er, destruction, or regeneration. Charismatic energies in either the self or one's world.

### Michael Munkasey - Midpoints: Unleashing the Power of the Planets

- Source heading: `SUN/PLUTO`
- Source page: `87`

#### Basic Ideas

Your fundamental urge to exert control over all situations, your capacity or determination to defeat or ally with corrupt forces as they rise around you, and the mastery you show against selfcorruption are prominent with this combination. Your commitment to concentrating yourself into the essence of what you are as a person, the secret motivations you rally your inner strength around, and the obsession you have with increasing your self-confidence are also here. You appear as a person who has a deep and formidable willpower, and one who is not easily swayed from important decisions about where your life is going. You may appear to others to have an easygoing outer facade, but inwardly you are a tower of strength and determination. The strength and resolution you bring thru these motifs to effect what you want in life is immense. You do not give up easily against anything.

#### In Your Personal Life

- Thesis: The force of will and determination you bring toward achieving your objectives; the unswerving reliability you offer to others; keeping secrets under all situations; the success you achieve using threats.
- Anti: Ruthless pursuit of your goals; focusing on activities which enable the accumulation of power; punishment for those who cannot perform their tasks; squandering your will by giving up on your principles.

#### In Your Relationships

- Thesis: You need to express your deeply felt emotions to a partner who also responds in kind; a deep need for truth between people; expressions of loyalty or respect and how these are reciprocated by your partner.
- Anti: Deep feelings of hurt when another has betrayed your love or trust; an inability to find another who can respond with intense emotions; your need to dominate another person thru the use of love or sex.

#### With Body or Mind

The role of the colon in maintaining your overall health; susceptibility to any infections caused by toxic conditions in the body or environment.

#### In Politics or Business

- Thesis: Changes of policy or direction from the leadership; new leadership and the changing of policy and direction; the governing authority used to control threatened dissent or subversion despite its cause or sources.
- Anti: Accumulation of an excessive amount of armed strength; the use of secret police to exert authority and control over others; the influence of criminal organizations; extremes of corruption which waste resources.

#### Munkasey Concepts Companion

- [Michael Munkasey - Sun/Pluto Concepts](../derived/munkasey-sun-pluto-concepts.md)

### Hajo Banzhaf and Anna Haebler - Keywords for Astrology

- Source section: `Sun-Pluto: Power`
- PDF page(s): `287`

#### Banzhaf/Haebler Aspect Keywords

- archetype: The Mighty King and the Sorcerer
- shadow: The Despot and the Gray Eminence
- comparison: Ego SHADOW Foreground Background Light Dark Creation Rearrangement Aura Magnetism
- general: Experience and consciousness of power and helplessness . The encounter of the self with its shadow . The transformation of the personality .
- harmony: The Shaman. Enormous powers of the soul—frequently unconscious to a large degree—that can be used for both the benefit and the destruction of others: powers of suggestion, healing powers, hypnotic abilities, and the subtle but highly effective power of magnetically attracting, fascinating, and captivating other people, as well as causing situations and events to occur on the basis of enormous powers of desire.
- discord: The Possessed Soul. Dark, dubious character that is not strong enough to resist the temptations of power. Tries to bind others to oneself, make them dependent and enslaved in order to control and exploit them in an emotional, physical, and/or material way. Possessed by a thirst for power.

## Comparative Schema

- core meaning: source-native axis statements from each ingested source are preserved side by side above.
- psychology: aphoristic, experiential, aspect-family, and thesis/anti formulations remain source-native instead of being flattened together.
- body/health: sources that isolate bodily implications keep them inside their own entries, and Munkasey adds an explicit `With Body or Mind` field.
- social/relationship: interpersonal implications remain inside their source blocks, and Munkasey's relationship thesis/anti stays separate.
- events/manifestations: Munkasey adds politics/business axis emphases, Carter remains axis-level aspect doctrine where present, and oriented activation pages stay unchanged.
- conflicts/notes: source `+` headings are normalized as midpoint-axis identities, and Munkasey's page-3 `CONCEPTS` list lives on the linked companion page instead of being merged into doctrine.

## Related Activations

- [Sun/Pluto = Admetos](../activations/sun-pluto-equals-admetos.md)
- [Sun/Pluto = Apollon](../activations/sun-pluto-equals-apollon.md)
- [Sun/Pluto = Asc](../activations/sun-pluto-equals-asc.md)
- [Sun/Pluto = Chiron](../activations/sun-pluto-equals-chiron.md)
- [Sun/Pluto = Cupido](../activations/sun-pluto-equals-cupido.md)
- [Sun/Pluto = Hades](../activations/sun-pluto-equals-hades.md)
- [Sun/Pluto = Jupiter](../activations/sun-pluto-equals-jupiter.md)
- [Sun/Pluto = Kronos](../activations/sun-pluto-equals-kronos.md)
- [Sun/Pluto = Mars](../activations/sun-pluto-equals-mars.md)
- [Sun/Pluto = MC](../activations/sun-pluto-equals-mc.md)
- [Sun/Pluto = Mercury](../activations/sun-pluto-equals-mercury.md)
- [Sun/Pluto = Moon](../activations/sun-pluto-equals-moon.md)
- [Sun/Pluto = Neptune](../activations/sun-pluto-equals-neptune.md)
- [Sun/Pluto = Node](../activations/sun-pluto-equals-node.md)
- [Sun/Pluto = Poseidon](../activations/sun-pluto-equals-poseidon.md)
- [Sun/Pluto = Saturn](../activations/sun-pluto-equals-saturn.md)
- [Sun/Pluto = Uranus](../activations/sun-pluto-equals-uranus.md)
- [Sun/Pluto = Venus](../activations/sun-pluto-equals-venus.md)
- [Sun/Pluto = Vernal Point](../activations/sun-pluto-equals-vernal-point.md)
- [Sun/Pluto = Vulcanus](../activations/sun-pluto-equals-vulcanus.md)
- [Sun/Pluto = Zeus](../activations/sun-pluto-equals-zeus.md)

## Contradictions

- No direct contradiction is recorded yet among the ingested source entries on this axis.
- Differences are preserved as distinct source voices, emphases, and source structures rather than flattened into one wording.

<a id="derived-synthesis"></a>

## Derived Synthesis

- `Sun/Pluto` is the axis of concentrated will, personal power, regeneration, and the drive to become stronger through crisis or deep self-confrontation. It combines identity, purpose, vitality, and leadership with intensity, secrecy, pressure, and transformative force.
- Chart expression: charisma, determination, self-mastery, resilience, influence, and the ability to remake one's life or direction through sheer inner force. Liabilities: domination, ego compulsion, power struggles, paranoia, ruthlessness, and a tendency to attract ordeals that test whether strength is being used for renewal or control.

## Links

- [Sun](../factors/sun.md)
- [Pluto](../factors/pluto.md)
- [Alfred Witte, Ludwig Rudolph & Hermann Lefeldt - Rules for Planetary Pictures](../sources/alfred-witte-ludwig-rudolph-hermann-lefeldt-rules-for-planetary-pictures.md)
- [Udo Rudolph - ABC for Planetary Pictures](../sources/udo-rudolph-abc-fur-planetenbilder.md)
- [Reinhold Ebertin - The Combination of Stellar Influences](../sources/reinhold-ebertin-the-combination-of-stellar-influences.md)
- [Michelle Falis - Planet Combinations: Astrological Brainstorms](../sources/michelle-falis-planet-combinations-astrological-brainstorms.md)
- [John Sandbach - Midpoints: A Kabbalistic Compendium of Meanings for Astrological Midpoints](../sources/john-sandbach-midpoints-a-kabbalistic-compendium-of-meanings-for-astrological-midpoints.md)
- [Robert Hand - Horoscope Symbols](../sources/robert-hand-horoscope-symbols.md)
- [Michael Munkasey - Midpoints: Unleashing the Power of the Planets](../sources/michael-munkasey-midpoints-unleashing-the-power-of-the-planets.md)
- [Hajo Banzhaf and Anna Haebler - Keywords for Astrology](../sources/hajo-banzhaf-anna-haebler-keywords-for-astrology.md)
