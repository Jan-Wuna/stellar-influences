---
title: Sun/Zeus
page_type: axis
slug: sun-zeus
status: source_ingested
framework_scope: comparative
factors:
  - Sun
  - Zeus
normalized_axis: Sun/Zeus
factor_a: Sun
factor_b: Zeus
related_activations:
  - Sun/Zeus = Admetos
  - Sun/Zeus = Apollon
  - Sun/Zeus = Asc
  - Sun/Zeus = Cupido
  - Sun/Zeus = Hades
  - Sun/Zeus = Jupiter
  - Sun/Zeus = Kronos
  - Sun/Zeus = Mars
  - Sun/Zeus = MC
  - Sun/Zeus = Mercury
  - Sun/Zeus = Moon
  - Sun/Zeus = Neptune
  - Sun/Zeus = Node
  - Sun/Zeus = Pluto
  - Sun/Zeus = Poseidon
  - Sun/Zeus = Saturn
  - Sun/Zeus = Uranus
  - Sun/Zeus = Venus
  - Sun/Zeus = Vernal Point
  - Sun/Zeus = Vulcanus
related_triad_hubs:
  - Sun Asc Zeus
  - Sun Cupido Zeus
  - Sun Hades Zeus
  - Sun Jupiter Zeus
  - Sun Mars Zeus
  - Sun MC Zeus
  - Sun Mercury Zeus
  - Sun Moon Zeus
  - Sun Neptune Zeus
  - Sun Node Zeus
  - Sun Pluto Zeus
  - Sun Saturn Zeus
  - Sun Uranus Zeus
  - Sun Venus Zeus
  - Sun Zeus Admetos
  - Sun Zeus Apollon
  - Sun Zeus Kronos
  - Sun Zeus Poseidon
  - Sun Zeus Vulcanus
  - Vernal Point Sun Zeus
aliases:
  - Zeus/Sun
source_pages:
  - alfred-witte-ludwig-rudolph-hermann-lefeldt-rules-for-planetary-pictures
  - udo-rudolph-abc-fur-planetenbilder
updated_at: 2026-05-04
---

## Identity

- Axis: `Sun/Zeus`
- Astronomicon axis: `S/£`
- Canonical page type: comparative axis page grounded in source-native pair entries.

## Source Entries

### Alfred Witte, Ludwig Rudolph & Hermann Lefeldt - Rules for Planetary Pictures

#### Pair Summary

The burning body. A man with a goal. A born leader. Creative person. Hie procreative impulse. The rocket. Man’s procreative capacity. To be the leader. The physical fire. Inflammable objects. Exposed to physical compulsion. Obligated to act. Creative day.

### Udo Rudolph - ABC for Planetary Pictures

#### ABC Pair Summary

Fire a day, fcurly man, guidance person, guidance center, corporal procreation, cracative man, leishmgs cntrum, person training, personal effort, creative person, Tagcs goal, and establishment of a centre

## Related Activations

- [Sun/Zeus = Admetos](../activations/sun-zeus-equals-admetos.md)
- [Sun/Zeus = Apollon](../activations/sun-zeus-equals-apollon.md)
- [Sun/Zeus = Asc](../activations/sun-zeus-equals-asc.md)
- [Sun/Zeus = Cupido](../activations/sun-zeus-equals-cupido.md)
- [Sun/Zeus = Hades](../activations/sun-zeus-equals-hades.md)
- [Sun/Zeus = Jupiter](../activations/sun-zeus-equals-jupiter.md)
- [Sun/Zeus = Kronos](../activations/sun-zeus-equals-kronos.md)
- [Sun/Zeus = Mars](../activations/sun-zeus-equals-mars.md)
- [Sun/Zeus = MC](../activations/sun-zeus-equals-mc.md)
- [Sun/Zeus = Mercury](../activations/sun-zeus-equals-mercury.md)
- [Sun/Zeus = Moon](../activations/sun-zeus-equals-moon.md)
- [Sun/Zeus = Neptune](../activations/sun-zeus-equals-neptune.md)
- [Sun/Zeus = Node](../activations/sun-zeus-equals-node.md)
- [Sun/Zeus = Pluto](../activations/sun-zeus-equals-pluto.md)
- [Sun/Zeus = Poseidon](../activations/sun-zeus-equals-poseidon.md)
- [Sun/Zeus = Saturn](../activations/sun-zeus-equals-saturn.md)
- [Sun/Zeus = Uranus](../activations/sun-zeus-equals-uranus.md)
- [Sun/Zeus = Venus](../activations/sun-zeus-equals-venus.md)
- [Sun/Zeus = Vernal Point](../activations/sun-zeus-equals-vernal-point.md)
- [Sun/Zeus = Vulcanus](../activations/sun-zeus-equals-vulcanus.md)

<a id="derived-synthesis"></a>
## Derived Synthesis

- This axis centers on the burning body, a man with a goal, and a born leader.
- Constructively this axis supports coherent integration; the shadow is overreach, rigidity, or internal split that undermines follow-through.

## Links

- [Sun](../factors/sun.md)
- [Zeus](../factors/zeus.md)
- [Alfred Witte, Ludwig Rudolph & Hermann Lefeldt - Rules for Planetary Pictures](../sources/alfred-witte-ludwig-rudolph-hermann-lefeldt-rules-for-planetary-pictures.md)
- [Udo Rudolph - ABC for Planetary Pictures](../sources/udo-rudolph-abc-fur-planetenbilder.md)
