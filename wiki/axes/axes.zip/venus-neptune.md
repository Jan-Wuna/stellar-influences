---
title: Venus/Neptune
page_type: axis
slug: venus-neptune
status: source_ingested
framework_scope: comparative
factors:
  - Venus
  - Neptune
normalized_axis: Venus/Neptune
factor_a: Venus
factor_b: Neptune
related_activations:
  - Venus/Neptune = Admetos
  - Venus/Neptune = Apollon
  - Venus/Neptune = Asc
  - Venus/Neptune = Chiron
  - Venus/Neptune = Cupido
  - Venus/Neptune = Hades
  - Venus/Neptune = Jupiter
  - Venus/Neptune = Kronos
  - Venus/Neptune = Mars
  - Venus/Neptune = MC
  - Venus/Neptune = Mercury
  - Venus/Neptune = Moon
  - Venus/Neptune = Node
  - Venus/Neptune = Pluto
  - Venus/Neptune = Poseidon
  - Venus/Neptune = Saturn
  - Venus/Neptune = Sun
  - Venus/Neptune = Uranus
  - Venus/Neptune = Vernal Point
  - Venus/Neptune = Vulcanus
  - Venus/Neptune = Zeus
related_triad_hubs:
  - Mercury Venus Neptune
  - Moon Venus Neptune
  - Sun Venus Neptune
  - Venus Chiron Neptune
  - Venus Jupiter Neptune
  - Venus Mars Neptune
  - Venus Neptune Admetos
  - Venus Neptune Apollon
  - Venus Neptune Asc
  - Venus Neptune Cupido
  - Venus Neptune Hades
  - Venus Neptune Kronos
  - Venus Neptune MC
  - Venus Neptune Node
  - Venus Neptune Pluto
  - Venus Neptune Poseidon
  - Venus Neptune Vulcanus
  - Venus Neptune Zeus
  - Venus Saturn Neptune
  - Venus Uranus Neptune
  - Vernal Point Venus Neptune
aliases:
  - Neptune/Venus
source_pages:
  - alfred-witte-ludwig-rudolph-hermann-lefeldt-rules-for-planetary-pictures
  - udo-rudolph-abc-fur-planetenbilder
  - reinhold-ebertin-the-combination-of-stellar-influences
  - michelle-falis-planet-combinations-astrological-brainstorms
  - charles-carter-the-astrological-aspects
  - john-sandbach-midpoints-a-kabbalistic-compendium-of-meanings-for-astrological-midpoints
  - robert-hand-horoscope-symbols
  - michael-munkasey-midpoints-unleashing-the-power-of-the-planets
  - hajo-banzhaf-anna-haebler-keywords-for-astrology
updated_at: 2026-06-20
---

## Identity

- Axis: `Venus/Neptune`
- Astronomicon axis: `Q/Y`
- Canonical page type: comparative axis page grounded in source-native pair entries.

## Source Entries

### Alfred Witte, Ludwig Rudolph & Hermann Lefeldt - Rules for Planetary Pictures

- Source heading: `VENUS/NEPTUNE`
- Source page: `203`

#### Pair Summary

Rapture. Sensitive, renouncing, false or unhappy love. Deceptive hopes. Hidden and secret feelings, sensations or sentiments. Wrong sex instinct. Renouncing love. Misfortune in love. Untrue love. Abnormality. Secret love. Disappointment in love. To be deceived in one’s affections.

### Udo Rudolph - ABC for Planetary Pictures

#### ABC Pair Summary

Joy in the air, harmony through subtlety, secret love, liehes exchange, love expectation, love weakness, refined love, preference for metaphysics, and future wishes

### Reinhold Ebertin - The Combination of Stellar Influences

#### Principle

An erotic imagination. Illusion.

#### Psychological Correspondence

+ Sensitivity in love, a person easily influenced, great receptivity for beauty, art and music. A dreamy nature, good taste, high ideals. - A mistaken sense of love, lack of good taste. Indecision, uncertainty, a seductible character, erotic aberrations. C Inclination to mysticism, romantic reverie, poorly developed sense of reality, artistic interests, sensitive nervous and glandular system.

#### Biological Correspondence

Weakened glandular functions, pathological enlargement of the glands, weakness of the sex organs.

#### Sociological Correspondence

Artists, musicians, mystics, dreamers and visionaries.

#### Probable Manifestations

+ Romantic and reveling love, longing for love, peculiar desires and objectives, an unstable existence and changing occupations. - Difficult realization of ideals and wishes, awakening from emotional infatuation with the awareness of disappointment or disillusionment. Wrong ways of love. Venus/Neptune 9/^

### Michelle Falis - Planet Combinations: Astrological Brainstorms

#### Falis Entry

Creating a fantasy around the one you love. Love fantasies. Delusional romance. Delusional attractions. Merging with music. Chaotic love. Chaotic art. Attracting chaos. Attracting visionaries. Visionary art. Visionary music. Celestial music. Celes tial love. Delusional creativity. Spiritual love. Spiritual music. Spiritual art. Fairytale romance. Romantic fantasy. Romantic movies. Confused rhythm. Confusing social interactions. A fool for love. Foolish in love. Unrealistic expectations in relation ships. Idealistic notions about love and relationships. Idealized art. Idealizing the object of affection. Idealizing attractions. Bride of spirit. Refined love nature. Deli cate romantic sensitivity. Artists, musicians, poets, romanticists and dreamers. Bo hemians and hippies. Jazz musicians. Disintegrated art forms. Free form music and poetry. Longing for Utopia. A martyr in relationships. A martyr for art. Art and fantasy merging. Fantasy art. Blurring gender lines. Blurring artistic genres. Inability to love just one individual. Passive receptivity. Passive attraction. Passive spirituality. Attracted to spiritual ex periences. Attracted to transcendental experiences. Attracted to escapist experi ences. Valuing selflessness. Valuing visionary ideals. Fusion music. People who transcend artistic boundaries. People who are visionaries. In love with a ghost. At tracted to psychic people and experiences. Attracted to people who are unreliable, elusive escapists. Attracted to people, situations and experiences that aren't real. Desiring mystical union. Desiring unrealistic love. Envisioning an unreal reality. Re fined taste. Delicate artistic sensibilities. Vague ideas about love. Vague ideas about what you really want. Floating from thing to thing. Wanting to be psychic. Wanting to be a medium. Being attracted to dream-like experiences. Art inspired by dreams. Creativity inspired from a higher realm. Attracted to clair voyance and paranormal experiences. Elusive love. Elusive attractions. Disinte gration of personal affection. No boundaries in love. No boundaries in affection. No boundaries in art. No boundaries to sensual experience. The sensual world and spiritual world merging. Attracted to musicians, artists and poets. Attracted to the underdog. Difficulty discerning where one person ends and the other begins in a relationship. Soul love. Love that transcends reality and time. Impractical attractions, romances and relationships. Universal love. Universal compassion. Compassionate love. Compassionate values. Spiritual values. Money slips through your fingers. Gentle love. Love is sacrifice. Dissolution of personal desire. Inability to see the object of affection clearly. Love of the abstract. Love that knows no limits. The things that you want elude you. You can never quite grasp what you desire. Compassion and pity mixed with love. Feeling sorry for the one you love. Imperfect love. Loving those with impairments or disabilities. Loving altered states. Attracted to drug culture. Attracted to experiences that offer escape. Escaping through music. Escaping through drugs and alcohol. Escaping through affairs and relationships. Loving vague, intangible experiences. Too sensi tive for everyday life. Permeable love nature. A diffuse love nature. Personal love eludes you. A higher love. Personal love and transcendent love combined. Love on a higher plane. Sloppy love affairs. Romantic beauty. Poetic beauty. Fascination.

### Charles Carter - The Astrological Aspects

#### Harmonious Aspects

The combination of the influences of these planets is probably one of the most delicate known to us, and neither its good nor its discordant effects are always very perceptible except in the case of those of sensitive temperament. Even among such there are many who are unable to express the effects in such manner as to render them intelligible to others.

Probably the contact is most easily expressed in the form of music, but it may also come through the finer expressions of other forms of art, and in the hands of a genius, it may be, even appear in the guise of poetry. It is pre-eminently the artist combination and is more nearly related to beauty than to either the moral or the scientific spheres.

It is sympathetic, but, like most Venus contacts, there is some limitation in the practical expression of sympathy; it is too refined an influence to care about work of a sordid description.

Among ordinary people it usually signifies good taste, a liking for music and other forms of art, good nature but much emotionalism, with little capacity for settled employment or hard work, except of an artistic character. It may be dreamy and visionary.

There may be high spiritual development, but in itself the influence is not sufficiently powerful to achieve much either on the mystic path or any other - in this respect the Inharmonious aspects, being more energetic, are better. Sometimes it may indicate a tendency to indolence and dependence on others; it is certainly likely to cause others to be helpful to the native in his need.

On the practical side it is good for all matters under the houses occupied and ruled, for all transactions with Venus-Neptunian persons, such as artists, actors, musicians and young women who are in any way connected with the sea or the seaside. Similarly the Neptune influence may come through other Neptunian channels, such as liquor, tobacco, drugs or marine affairs. It favours easy fortunes and a certain degree of luxury, but it can be its own enemy through imprudence and lack of energy and sense.

In respect of health this combination is never very important, and even good aspects tend to a certain delicacy of constitution and a susceptible bodily condition.

#### The Conjunction

The temper is usually very kind-hearted, with particular fondness for animals, but it is rare to find persons with this configuration who are not highly-strung, temperamental and more than averagely sensitive. Frequently there is a peculiarity of the temperament which is best described by the hackneyed adjective "sweet" with the most abundant sympathies for all suffering. There may be interest in art, or in mysticism, or in mystic art, but it is necessary not to expect too much from any aspects of these planets unless the remainder of the map is of a high order.

It often happens that the affections are disappointed or denied full expression.

Though often weak in itself, it may form a constituent part of the nativities of artistic geniuses.

There is a tendency for this Conjunction to bring sorrow and loneliness into the life, often with some inhibition of the health, such as nervous weakness or a general delicacy of constitution. It does not favour any kind of worldly success or ability to combat or overcome the harsh realities of life. Frequently the native is in some way sheltered or he seeks or is brought into retirement. It often denotes disappointed attachments or anxiety through the partner, such as his being sickly, in which case the aspect may take on a markedly protective and cherishing character.

In two cases at least (King George of Greece and "the Girl in the Peasanhall Case," Notable Nativities, 786) this Conjunction has been associated with murder, although it can only be regarded as an accessory in such matters, being scarcely of a violent nature.

#### Inharmonious Aspects

In some respects these seem to lead to more definite results than the Trine and Sextile, for they bestow a divine discontent, and a constant restless seeking for an ideal which is not easily realisable on earth. This is particularly so in matters of the affections. The ideals are indeed very high, and there may be a persistent dissatisfaction both with things and persons, varying from a petulant or peevish attitude, to a noble aspiration and persistent endeavor to seek for a fuller realisation of inner visions. There may be a difficulty in adapting oneself to surroundings or to people with whom contact is made; almost always the affections are extremely sensitive and responsive.

The devotion to art may be as great as the good aspects, but there will be difficulty in following this path, or there may be eccentricities of expression - nevertheless, the Inharmonious combinations are frequently found in the nativities of great artists.

Although the good aspects of these two planets are naturally more favourable for happiness and easy conditions, it seems that, so far as achievement, moral character and artistic ability go, the Inharmonious aspects are in no way inferior to them; in fact, they may be better inasmuch as they may produce more energy.

A tendency to "sit on the fence" and to avoid definiteness in judgment and action seems sometimes to occur. As a result of the fact that the emotional nature is abnormally sensitive and unstable, happiness in all relationships with others, and particularly in marriage, is frequently endangered, a slight difference often assuming imaginary importance, whilst the native may easily form clandestine connections with others owing to his or her extreme susceptibility to affectional influences coupled with a dislike of open rupture or violent "scenes."

This tendency externalizes in the shape of confused and deceptive conditions, uncertainty, treachery and instability.

The imagination is very active and this may also lead to moral lapses.

Much the same circumstances generally arise in matters of the 2nd house. The native may himself be victimised, or, in a generally weak natus, there may be attempts to defraud others. Sometimes it is to be observed that the native himself seems to have some kind of mental warp which makes him unable to see clearly in these matters, so that he appears hardly to realise what he is doing and his very victims cannot believe that his intentions have been evil. In money matters persons with this contact should be careful to avoid any sort of entanglements and would do well carefully to avoid anything that has the Neptunian characteristics; they may otherwise easily be involved in some kind of "South Sea Bubble" collapse.

Females ought to be particularly careful in their male associates, for the contact threatens deception, and the men that are met are likely sometimes to prove by no means what they seem. Any trace of addiction to drink or drugs may lead to something very serious. Sometimes ultimate ruin is hidden by an illusive preliminary happiness.

In a word, the native should practise utter directness and straightforwardness in all his dealings, and should rigidly require the same behaviour from others, in so far as it is in his power to do so.

Often the reputation suffers through questionable relationships, and sex or finance are usually the grounds of attack. One may mention Nicholas II of Russia, who suffered destruction in large part through Rasputin, the monk.

Needless to say, any psychic, or other mediumistic practices are particularly dangerous to those with these positions.

Since Venus has a general reference to objects of affection, these contacts may indicate anxiety with regard to the mother, sisters, children and even pets.

The health is usually to some extent affected; and if either planet has special reference to physical well-being, then sensitiveness, especially to drugs, may be expected. The vicinity of the sea is harmful, and dry bracing air is beneficial.

There is often a tendency to experiment with diet and to practice vegetarianism, owing to the sensitive character of the contact. But this course is likely, in the case of the bad aspects, to prove difficult or unsatisfactory.

#### Examples

- Harmonious: Queen Victoria, Lord Northcliffe, Goethe, Rupert Brooke, Mussolini, Byron, Edward VII, Lindbergh.
- The Conjunction: Victor Hugo, Valentino, S.T. Coleridge, Louis I of Bavaria (lost throne through infatuation for dancing girl), Swindenburne.
- Inharmonious: Rider Haggard, W.B. Yeats, President Harding, the ex-Kaiser, Joseph Chamberlain, the poet Crabbe, Lord Roberts (lost son in Boer War), Marie Antoinette, Edgar Allan Poe.

### John Sandbach - Midpoints: A Kabbalistic Compendium of Meanings for Astrological Midpoints

#### Principle

Idealized love. Self-sacrifice in love. A refined expression of love. To engage in imagining beautiful illusions and fantasies to which one can potentially become addicted. Attraction to that which is refined and/or exalted. Confusion in love and in relationships. Impracticality where both love and money are concerned but also the ability to use one’s intuition to make money and to know what the loved one needs. The ability to intuit the true worth of things.

#### Process

The purifying and refining of one’s ability to love. Developing the ability to see through illusions into the eternal value and beauty underlying everything. The refine ment of one’s tastes.

### Robert Hand - Horoscope Symbols

#### Pair Delineation

The abstract ideal of the beautiful, the romantic ideal. Artistic taste and creativity. Romantic ideals in relationships, illusions about or in love (often leading to disappointment). Platonic love.

Love of people vastly better or worse off than oneself, including those who take care of one or need to be taken care of.

### Michael Munkasey - Midpoints: Unleashing the Power of the Planets

- Source heading: `VENUS/NEPTUNE`
- Source page: `203`

#### Basic Ideas

These themes denote an appreciation of how dreams and visions can become the prototypes for future reality. You may feel delight in accomplishing a successful deception, gain enjoyment from the subtleness of creating beauty, or derive pleasure from the study and application of mysticism or magic. You may create subtle ways to display your jealousies, gain satisfaction from being evasive or illusive, and feel affection when you receive romantic gestures from another. These motifs may weaken your attempts at being more beautiful or lovely, bring confusion about using makeup or body ornaments, and help create false impressions about the admiration you show to others. You may be tempted to be lazy or indulge in pure sensual gratifications, earn appreciation from being more holy or obedient, delight in wearing creative disguises, or appease your yearnings for total personal freedom.

#### In Your Personal Life

- Thesis: Inspiration for creating new concepts in music or the arts; increased appreciation for subtle or devious means of enjoying reality; temptations to neglect resources; assets which are allowed to waste away.
- Anti: Receiving pleasure when evading or deceiving others; added envy felt when another is more romantic; additional laxity or looseness as a part of your personality; pleasure derived from causing confusion or loss.

#### In Your Relationships

- Thesis: Increased appreciation for the quality of romance that a good partner can bring to you; compassion shown for those you love; romantic feelings of love from those close to you; idealized love feelings.
- Anti: Deception thru romance; an imperfect understanding of romantic love; nebulous promises of affection become easier to believe and cling to; neglect of your partner’s satisfaction, or your partner neglects you.

#### With Body or Mind

Inner reactions to drugs; weakness in the kidneys or bladder; weakened senses in general; defects, poor storage, or chemicals which weaken blood supplies.

#### In Politics or Business

- Thesis: Appeals to the ideals of the people; an inflated treasury; use of inflation as a means for controlling or manipulating growth; wealth derived from gas, chemicals, or oil; exaggerates or misstates internal resources.
- Anti: Scandals concerning the misuse of, or deceptive practices within, the treasury or internal resources; subversives who desire to gain access to finances; spies in the financial branches; monetary fraud; art deception.

#### Munkasey Concepts Companion

- [Michael Munkasey - Venus/Neptune Concepts](../derived/munkasey-venus-neptune-concepts.md)

### Hajo Banzhaf and Anna Haebler - Keywords for Astrology

- Source section: `Venus-Neptune: The Dream of Love`
- PDF page(s): `315`

#### Banzhaf/Haebler Aspect Keywords

- archetype: The Beautiful Muse and the Wonderful One
- shadow: The Weakling and the Drinker
- comparison: Art Spirituality Connecting Merging Loving Adoring Eroticism Mysticism
- general: Transcendental love . Becoming flooded with music . Experiencing boundless love . Achieving highest spirituality through love . Being touched in one's innermost heart by art . Finding redemption through love . Being inspired to artistic creativity by the divine . The dream relationship .
- harmony: Intuitive Love. Deep feeling of being soul mates and a wordless understanding of each other that borders on perfection. Great willingness to be devoted and to sacrifice. Being upheld by the spirit of love. Delicacy of feeling. Mystic, romantic, idealized love that leads to experiences beyond the personal. Highly refined sense of taste and art, above all in the area of music.
- discord: Intoxication of Love. Insatiable, vast longing that makes a person extremely easy to seduce. “High-flying” love and intoxication of love with subsequent bitter disillusionment. Getting lost in deceptive, misleading ideals and confused, unclear relationships. Violently getting high with intoxicants as aphrodisiacs. Getting off the track erotically.

## Comparative Schema

- core meaning: source-native axis statements from each ingested source are preserved side by side above.
- psychology: aphoristic, experiential, aspect-family, and thesis/anti formulations remain source-native instead of being flattened together.
- body/health: sources that isolate bodily implications keep them inside their own entries, and Munkasey adds an explicit `With Body or Mind` field.
- social/relationship: interpersonal implications remain inside their source blocks, and Munkasey's relationship thesis/anti stays separate.
- events/manifestations: Munkasey adds politics/business axis emphases, Carter remains axis-level aspect doctrine where present, and oriented activation pages stay unchanged.
- conflicts/notes: source `+` headings are normalized as midpoint-axis identities, and Munkasey's page-3 `CONCEPTS` list lives on the linked companion page instead of being merged into doctrine.

## Related Activations

- [Venus/Neptune = Admetos](../activations/venus-neptune-equals-admetos.md)
- [Venus/Neptune = Apollon](../activations/venus-neptune-equals-apollon.md)
- [Venus/Neptune = Asc](../activations/venus-neptune-equals-asc.md)
- [Venus/Neptune = Chiron](../activations/venus-neptune-equals-chiron.md)
- [Venus/Neptune = Cupido](../activations/venus-neptune-equals-cupido.md)
- [Venus/Neptune = Hades](../activations/venus-neptune-equals-hades.md)
- [Venus/Neptune = Jupiter](../activations/venus-neptune-equals-jupiter.md)
- [Venus/Neptune = Kronos](../activations/venus-neptune-equals-kronos.md)
- [Venus/Neptune = Mars](../activations/venus-neptune-equals-mars.md)
- [Venus/Neptune = MC](../activations/venus-neptune-equals-mc.md)
- [Venus/Neptune = Mercury](../activations/venus-neptune-equals-mercury.md)
- [Venus/Neptune = Moon](../activations/venus-neptune-equals-moon.md)
- [Venus/Neptune = Node](../activations/venus-neptune-equals-node.md)
- [Venus/Neptune = Pluto](../activations/venus-neptune-equals-pluto.md)
- [Venus/Neptune = Poseidon](../activations/venus-neptune-equals-poseidon.md)
- [Venus/Neptune = Saturn](../activations/venus-neptune-equals-saturn.md)
- [Venus/Neptune = Sun](../activations/venus-neptune-equals-sun.md)
- [Venus/Neptune = Uranus](../activations/venus-neptune-equals-uranus.md)
- [Venus/Neptune = Vernal Point](../activations/venus-neptune-equals-vernal-point.md)
- [Venus/Neptune = Vulcanus](../activations/venus-neptune-equals-vulcanus.md)
- [Venus/Neptune = Zeus](../activations/venus-neptune-equals-zeus.md)

## Contradictions

- No direct contradiction is recorded yet among the ingested source entries on this axis.
- Differences are preserved as distinct source voices, emphases, and source structures rather than flattened into one wording.

<a id="derived-synthesis"></a>

## Derived Synthesis

- `Venus/Neptune` is the axis of idealized love, refined beauty, romantic imagination, and compassionate longing. It combines affection, art, pleasure, and value with dream, mysticism, glamour, sacrifice, and the urge to transcend ordinary personal desire.
- Chart expression: artistic sensitivity, poetic or spiritual love, empathy, tenderness, enchantment, and attraction to what feels elevated, elusive, or redemptive. Liabilities: illusion, disappointment, porous boundaries, deception, escapism, impractical attachments, and financial or emotional leakage when fantasy replaces clear value judgment.

## Links

- [Venus](../factors/venus.md)
- [Neptune](../factors/neptune.md)
- [Alfred Witte, Ludwig Rudolph & Hermann Lefeldt - Rules for Planetary Pictures](../sources/alfred-witte-ludwig-rudolph-hermann-lefeldt-rules-for-planetary-pictures.md)
- [Udo Rudolph - ABC for Planetary Pictures](../sources/udo-rudolph-abc-fur-planetenbilder.md)
- [Reinhold Ebertin - The Combination of Stellar Influences](../sources/reinhold-ebertin-the-combination-of-stellar-influences.md)
- [Michelle Falis - Planet Combinations: Astrological Brainstorms](../sources/michelle-falis-planet-combinations-astrological-brainstorms.md)
- [Charles Carter - The Astrological Aspects](../sources/charles-carter-the-astrological-aspects.md)
- [John Sandbach - Midpoints: A Kabbalistic Compendium of Meanings for Astrological Midpoints](../sources/john-sandbach-midpoints-a-kabbalistic-compendium-of-meanings-for-astrological-midpoints.md)
- [Robert Hand - Horoscope Symbols](../sources/robert-hand-horoscope-symbols.md)
- [Michael Munkasey - Midpoints: Unleashing the Power of the Planets](../sources/michael-munkasey-midpoints-unleashing-the-power-of-the-planets.md)
- [Hajo Banzhaf and Anna Haebler - Keywords for Astrology](../sources/hajo-banzhaf-anna-haebler-keywords-for-astrology.md)
